"""
services/payments.py
Payment provider abstraction. Balance is only ever credited after a
VERIFIED payment confirmation — nothing here fabricates success.

ManualProvider is the only fully-working provider out of the box: it
creates a pending payment record that an admin confirms with
`/admin confirm-payment`, which is a safe default for any deployment that
hasn't wired up a real payment gateway yet. Razorpay/UPI are documented
stubs — implement their webhook verification before enabling them.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Optional

from config import settings
from database import Database
from utils.helpers import new_tx_id, now_utc
from utils.logger import bot_logger


class PaymentError(Exception):
    pass


class PaymentProvider(ABC):
    name: str = "base"

    @abstractmethod
    async def initiate(self, db: Database, user_id: int, amount: float) -> dict:
        """Create a pending payment record. Returns instructions for the user."""

    @abstractmethod
    async def verify(self, db: Database, payment_id: str, external_payload: dict) -> bool:
        """Verify a webhook/callback payload against the provider. Returns True if genuinely paid."""


class ManualProvider(PaymentProvider):
    """Pending-until-admin-confirms flow. Safe default with no external dependency."""

    name = "manual"

    async def initiate(self, db: Database, user_id: int, amount: float) -> dict:
        payment_id = new_tx_id()
        await db._conn.execute(
            "INSERT INTO payments (id, user_id, amount, provider, status, created_at) "
            "VALUES (?, ?, ?, ?, 'pending', ?)",
            (payment_id, user_id, amount, self.name, now_utc().isoformat()),
        )
        await db._conn.commit()
        return {
            "payment_id": payment_id,
            "instructions": (
                f"Payment `{payment_id}` for {amount:.2f} credits created as PENDING.\n"
                "An admin must confirm it with `/admin confirm-payment` once funds are received "
                "through your organization's actual payment channel."
            ),
        }

    async def verify(self, db: Database, payment_id: str, external_payload: dict) -> bool:
        # Manual provider is only confirmed via the admin command, not automatically.
        return False


class RazorpayProvider(PaymentProvider):
    """
    Documented stub. To implement:
      pip install razorpay
      client = razorpay.Client(auth=(key_id, key_secret))
      order = client.order.create({...})
      # verify webhook signature with razorpay.utility.verify_webhook_signature
    Only call db credit logic after signature verification succeeds.
    """

    name = "razorpay"

    async def initiate(self, db: Database, user_id: int, amount: float) -> dict:
        raise PaymentError("RazorpayProvider is not implemented. See services/payments.py docstring.")

    async def verify(self, db: Database, payment_id: str, external_payload: dict) -> bool:
        raise PaymentError("RazorpayProvider is not implemented. See services/payments.py docstring.")


class UPIProvider(PaymentProvider):
    """Documented stub — implement with your UPI PSP's intent/callback verification."""

    name = "upi"

    async def initiate(self, db: Database, user_id: int, amount: float) -> dict:
        raise PaymentError("UPIProvider is not implemented. See services/payments.py docstring.")

    async def verify(self, db: Database, payment_id: str, external_payload: dict) -> bool:
        raise PaymentError("UPIProvider is not implemented. See services/payments.py docstring.")


def get_payment_provider(provider_type: Optional[str] = None) -> PaymentProvider:
    provider_type = (provider_type or settings.payment_provider).lower()
    if provider_type == "manual":
        return ManualProvider()
    if provider_type == "razorpay":
        return RazorpayProvider()
    if provider_type == "upi":
        return UPIProvider()
    bot_logger.warning("Unknown PAYMENT_PROVIDER '%s' — falling back to manual.", provider_type)
    return ManualProvider()


async def confirm_payment(db: Database, payment_id: str, admin_id: int) -> tuple[bool, str]:
    cur = await db._conn.execute("SELECT * FROM payments WHERE id = ?", (payment_id,))
    payment = await cur.fetchone()
    if not payment:
        return False, "Payment not found."
    if payment["status"] == "confirmed":
        return False, "Payment already confirmed."
    async with db.transaction() as conn:
        await conn.execute(
            "UPDATE payments SET status = 'confirmed', confirmed_at = ? WHERE id = ?",
            (now_utc().isoformat(), payment_id),
        )
        cur2 = await conn.execute("SELECT balance FROM users WHERE discord_id = ?", (payment["user_id"],))
        row = await cur2.fetchone()
        new_balance = (row["balance"] if row else 0) + payment["amount"]
        await conn.execute(
            "UPDATE users SET balance = ? WHERE discord_id = ?", (new_balance, payment["user_id"])
        )
        await conn.execute(
            "INSERT INTO transactions (id, user_id, amount, type, description, created_at) "
            "VALUES (?, ?, ?, 'topup', ?, ?)",
            (new_tx_id(), payment["user_id"], payment["amount"], f"Payment {payment_id} confirmed", now_utc().isoformat()),
        )
    await db.log_audit(admin_id, "confirm_payment", target=f"payment:{payment_id}")
    return True, f"Confirmed. {payment['amount']:.2f} credits added to <@{payment['user_id']}>."
