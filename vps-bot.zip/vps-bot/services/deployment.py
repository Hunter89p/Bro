"""
services/deployment.py
Async deployment queue with worker pool. Ensures:
  - Balance deduction -> resource reservation -> VPS creation -> DB confirmation
  - Full rollback (refund + record release) if any step fails
  - Only one deployment consumes a given slice of host resources at a time
    (guarded by an asyncio.Lock around the capacity check + reservation)
"""
from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from typing import Awaitable, Callable, Optional

import discord

from config import settings
from database import Database
from providers.base import ProviderError, VPSProvider, VPSSpec
from services.security import encrypt_secret
from utils.helpers import (
    generate_container_name,
    generate_password,
    new_error_id,
    now_utc,
)
from utils.logger import deployment_logger, error_logger
from datetime import timedelta


@dataclass
class DeploymentRequest:
    owner_id: int
    hostname: str
    os_image: str
    plan_row: dict
    progress_cb: Optional[Callable[[str], Awaitable[None]]] = None
    future: asyncio.Future = field(default_factory=asyncio.Future)


class DeploymentQueue:
    def __init__(self, db: Database, provider: VPSProvider) -> None:
        self.db = db
        self.provider = provider
        self._queue: asyncio.Queue[DeploymentRequest] = asyncio.Queue()
        self._reservation_lock = asyncio.Lock()
        self._workers: list[asyncio.Task] = []
        self._in_flight = 0

    def start_workers(self) -> None:
        for i in range(settings.deployment_worker_count):
            self._workers.append(asyncio.create_task(self._worker_loop(i)))

    async def stop_workers(self) -> None:
        for w in self._workers:
            w.cancel()

    async def submit(self, request: DeploymentRequest) -> dict:
        """Enqueue a deployment and await its result: {ok, vps_id?, error?, error_id?}."""
        loop = asyncio.get_running_loop()
        request.future = loop.create_future()
        await self._queue.put(request)
        return await request.future

    async def _worker_loop(self, worker_id: int) -> None:
        while True:
            request = await self._queue.get()
            try:
                result = await self._process(request)
                if not request.future.done():
                    request.future.set_result(result)
            except Exception as exc:  # noqa: BLE001
                error_id = new_error_id()
                error_logger.exception("Unhandled deployment worker error [%s]: %s", error_id, exc)
                if not request.future.done():
                    request.future.set_result(
                        {"ok": False, "error": "Internal error during deployment.", "error_id": error_id}
                    )
            finally:
                self._queue.task_done()

    async def _progress(self, request: DeploymentRequest, step: str) -> None:
        if request.progress_cb:
            try:
                await request.progress_cb(step)
            except Exception:  # noqa: BLE001
                pass

    async def _process(self, request: DeploymentRequest) -> dict:
        plan = request.plan_row
        error_id = None
        reserved = False
        charged = False
        container_created = False
        container_name = generate_container_name()

        try:
            await self._progress(request, "Checking resources...")

            async with self._reservation_lock:
                capacity = await self.provider.host_capacity()
                if (
                    plan["cpu"] > capacity["cpu_available"]
                    or plan["ram_mb"] > capacity["ram_available_mb"]
                    or plan["disk_gb"] > capacity["disk_available_gb"]
                ):
                    return {
                        "ok": False,
                        "error": "Insufficient host resources available right now. Try again later.",
                        "error_id": new_error_id(),
                    }
                # Reservation is implicit: we hold the lock through the DB insert below so no
                # concurrent deployment can double-count the same headroom.

                await self._progress(request, "Reserving resources & charging balance...")
                try:
                    await self.db.adjust_balance(
                        request.owner_id, -plan["price"], "purchase", f"Deploy {plan['name']} plan"
                    )
                    charged = True
                except ValueError:
                    return {"ok": False, "error": "Insufficient balance for this plan.", "error_id": new_error_id()}

                ssh_username = "root"
                ssh_password = generate_password()

                async with self.db.transaction() as conn:
                    vps_id = await self.db.create_vps_record(
                        conn,
                        {
                            "owner_id": request.owner_id,
                            "hostname": request.hostname,
                            "container_name": container_name,
                            "os": request.os_image,
                            "plan_id": plan["id"],
                            "plan_name": plan["name"],
                            "cpu": plan["cpu"],
                            "ram_mb": plan["ram_mb"],
                            "disk_gb": plan["disk_gb"],
                            "status": "provisioning",
                            "provider": self.provider.name,
                            "created_at": now_utc().isoformat(),
                            "expires_at": (now_utc() + timedelta(days=plan["duration_days"])).isoformat(),
                        },
                    )
                    ssh_port = await self.db.allocate_port(conn, vps_id, "ssh")
                reserved = True

            await self._progress(request, "Creating VPS...")
            spec = VPSSpec(
                container_name=container_name,
                hostname=request.hostname,
                os_image=request.os_image,
                cpu=plan["cpu"],
                ram_mb=plan["ram_mb"],
                disk_gb=plan["disk_gb"],
                ssh_port=ssh_port,
                ssh_username=ssh_username,
                ssh_password=ssh_password,
            )
            info = await self.provider.create_vps(spec)
            container_created = True

            await self._progress(request, "Configuring network...")
            ipv4 = info.get("ipv4")
            ipv6 = info.get("ipv6")

            await self._progress(request, "Generating SSH credentials...")
            await self.db.update_vps(
                vps_id,
                status="running",
                ipv4=ipv4,
                ipv6=ipv6,
                ssh_port=ssh_port,
                ssh_username=ssh_username,
                ssh_password_enc=encrypt_secret(ssh_password),
            )
            await self.db.log_deployment(request.owner_id, "success", vps_id=vps_id)
            deployment_logger.info(
                "Deployment success: user=%s vps_id=%s container=%s", request.owner_id, vps_id, container_name
            )

            return {
                "ok": True,
                "vps_id": vps_id,
                "ipv4": ipv4,
                "ipv6": ipv6,
                "ssh_port": ssh_port,
                "ssh_username": ssh_username,
                "ssh_password": ssh_password,  # returned once, in-memory only, never logged
            }

        except ProviderError as exc:
            error_id = new_error_id()
            error_logger.error("Provider error [%s]: %s", error_id, exc)
        except Exception as exc:  # noqa: BLE001
            error_id = new_error_id()
            error_logger.exception("Deployment error [%s]: %s", error_id, exc)

        # ---- rollback path ----
        await self._progress(request, "Rolling back...")
        if container_created:
            try:
                await self.provider.delete_vps(container_name)
            except ProviderError:
                pass
        if reserved:
            try:
                await self.db.release_ports(vps_id)  # type: ignore[possibly-undefined]
                await self.db.update_vps(vps_id, status="failed")  # type: ignore[possibly-undefined]
            except Exception:  # noqa: BLE001
                pass
        if charged:
            try:
                await self.db.adjust_balance(
                    request.owner_id, plan["price"], "refund", "Deployment failed — automatic refund"
                )
            except Exception:  # noqa: BLE001
                error_logger.error("CRITICAL: failed to refund user %s after failed deployment", request.owner_id)

        await self.db.log_deployment(request.owner_id, "failed", error_id=error_id, error_message="see error.log")
        return {"ok": False, "error": "Deployment failed. Your balance has been refunded.", "error_id": error_id}
