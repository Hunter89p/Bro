"""
services/billing.py
Subscription lifecycle: expiry warnings, suspension, grace-period deletion,
and renewal pricing. Runs as a scheduled background task from bot.py.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

import discord

from config import settings
from database import Database
from providers.base import ProviderError, VPSProvider
from utils.helpers import now_utc
from utils.logger import bot_logger, error_logger

WARN_3D = timedelta(days=3)
WARN_24H = timedelta(hours=24)


class BillingService:
    def __init__(self, db: Database, provider: VPSProvider, bot: discord.Client) -> None:
        self.db = db
        self.provider = provider
        self.bot = bot

    async def _notify_owner(self, owner_id: int, embed: discord.Embed) -> None:
        try:
            user = await self.bot.fetch_user(owner_id)
            await user.send(embed=embed)
        except discord.Forbidden:
            bot_logger.info("Could not DM user %s (DMs closed).", owner_id)
        except Exception as exc:  # noqa: BLE001
            error_logger.exception("Failed notifying user %s: %s", owner_id, exc)

    async def run_cycle(self) -> None:
        """One pass: check every active VPS for warnings / expiry / grace-period cleanup."""
        vps_list = await self.db.list_expiring()
        now = now_utc()
        for vps in vps_list:
            try:
                expires_at = datetime.fromisoformat(vps["expires_at"])
            except ValueError:
                continue
            remaining = expires_at - now

            if vps["status"] in ("running", "stopped"):
                if timedelta(0) < remaining <= WARN_3D and not vps["warned_3d"]:
                    await self._notify_owner(
                        vps["owner_id"],
                        discord.Embed(
                            title="⚠️ VPS expiring in 3 days",
                            description=f"`{vps['hostname']}` (#{vps['id']}) expires on {vps['expires_at']}. "
                                        f"Use `/renew {vps['id']}` to extend it.",
                            color=0xFEE75C,
                        ),
                    )
                    await self.db.update_vps(vps["id"], warned_3d=1)

                if timedelta(0) < remaining <= WARN_24H and not vps["warned_24h"]:
                    await self._notify_owner(
                        vps["owner_id"],
                        discord.Embed(
                            title="⚠️ VPS expiring in 24 hours",
                            description=f"`{vps['hostname']}` (#{vps['id']}) expires very soon. "
                                        f"Renew now with `/renew {vps['id']}` to avoid suspension.",
                            color=0xED4245,
                        ),
                    )
                    await self.db.update_vps(vps["id"], warned_24h=1)

                if remaining <= timedelta(0):
                    await self._suspend(vps)

            elif vps["status"] == "suspended":
                suspended_at_raw = vps["suspended_at"]
                if suspended_at_raw:
                    suspended_at = datetime.fromisoformat(suspended_at_raw)
                    grace_end = suspended_at + timedelta(hours=settings.default_grace_period_hours)
                    if now >= grace_end:
                        await self._delete_after_grace(vps)

    async def _suspend(self, vps) -> None:
        try:
            await self.provider.stop_vps(vps["container_name"])
        except ProviderError as exc:
            error_logger.warning("Suspend stop failed for vps %s: %s", vps["id"], exc)
        await self.db.update_vps(
            vps["id"], status="suspended", suspended_at=now_utc().isoformat(), warned_expired=1
        )
        await self.db.log_audit(0, "auto_suspend", target=f"vps:{vps['id']}", details="Subscription expired.")
        await self._notify_owner(
            vps["owner_id"],
            discord.Embed(
                title="🔒 VPS Suspended — Subscription Expired",
                description=(
                    f"`{vps['hostname']}` (#{vps['id']}) has been suspended.\n"
                    f"You have {settings.default_grace_period_hours}h to renew with "
                    f"`/renew {vps['id']}` before it is deleted."
                ),
                color=0xED4245,
            ),
        )

    async def _delete_after_grace(self, vps) -> None:
        try:
            await self.provider.delete_vps(vps["container_name"])
        except ProviderError as exc:
            error_logger.warning("Grace-period delete failed for vps %s: %s", vps["id"], exc)
        await self.db.release_ports(vps["id"])
        await self.db.update_vps(vps["id"], status="deleted")
        await self.db.log_audit(0, "auto_delete", target=f"vps:{vps['id']}", details="Grace period elapsed.")
        await self._notify_owner(
            vps["owner_id"],
            discord.Embed(
                title="🗑️ VPS Deleted",
                description=f"`{vps['hostname']}` (#{vps['id']}) was deleted after its grace period elapsed.",
                color=0xED4245,
            ),
        )

    async def renew(self, vps_id: int, owner_id: int) -> tuple[bool, str]:
        vps = await self.db.get_vps(vps_id)
        if not vps or vps["owner_id"] != owner_id:
            return False, "VPS not found."
        plan = await self.db.get_plan(vps["plan_id"])
        if not plan:
            return False, "Original plan no longer exists — contact an admin."
        try:
            await self.db.adjust_balance(owner_id, -plan["price"], "renewal", f"Renew VPS #{vps_id}")
        except ValueError:
            return False, "Insufficient balance."

        base = datetime.fromisoformat(vps["expires_at"])
        if base < now_utc():
            base = now_utc()
        new_expiry = base + timedelta(days=plan["duration_days"])

        updates = {
            "expires_at": new_expiry.isoformat(),
            "warned_3d": 0,
            "warned_24h": 0,
            "warned_expired": 0,
        }
        if vps["status"] == "suspended":
            try:
                await self.provider.start_vps(vps["container_name"])
                updates["status"] = "running"
                updates["suspended_at"] = None
            except ProviderError as exc:
                error_logger.warning("Failed restarting renewed vps %s: %s", vps_id, exc)

        await self.db.update_vps(vps_id, **updates)
        await self.db.log_audit(owner_id, "renew", target=f"vps:{vps_id}")
        return True, f"Renewed until {new_expiry.date().isoformat()}."
