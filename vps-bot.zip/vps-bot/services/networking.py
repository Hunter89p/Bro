"""
services/networking.py
Port validation and allocation logic. Actual DB-level port bookkeeping
lives in database.py (allocate_port/release_ports) so it can share the
same transaction as VPS creation; this module holds the pure validation
rules and the public helper used by cogs.
"""
from __future__ import annotations

from config import settings

PRIVILEGED_PORT_CEILING = 1024
RESERVED_PORTS = {22, 25, 53, 80, 443, 3306, 5432, 6379, 27017}


def validate_port(port: int) -> tuple[bool, str]:
    if port < 1 or port > 65535:
        return False, "Port must be between 1 and 65535."
    if port < PRIVILEGED_PORT_CEILING:
        return False, "Privileged ports (<1024) cannot be allocated to user VPS instances."
    if port in RESERVED_PORTS:
        return False, f"Port {port} is reserved for internal services."
    if not (settings.port_range_start <= port <= settings.port_range_end):
        return False, (
            f"Port must be within the configured range "
            f"{settings.port_range_start}-{settings.port_range_end}."
        )
    return True, ""


def build_ssh_command(ip: str, port: int, username: str) -> str:
    return f"ssh {username}@{ip} -p {port}"
