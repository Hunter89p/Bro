"""
services/security.py
Credential encryption-at-rest and safe subprocess execution helpers.

SSH passwords are shown to the owner exactly once (ephemeral DM/reply) and
stored encrypted at rest using Fernet (symmetric, key from env) so a raw
database leak doesn't hand out plaintext credentials. This is "avoid
plaintext where reasonably possible" — not a substitute for per-user SSH
keys, which is the stronger long-term design (see README).
"""
from __future__ import annotations

import asyncio
import os
import shlex
from typing import Sequence

from cryptography.fernet import Fernet

from utils.logger import security_logger

_KEY_ENV = "CREDENTIAL_ENCRYPTION_KEY"


def _get_fernet() -> Fernet:
    key = os.getenv(_KEY_ENV)
    if not key:
        # Generated once per process if missing — for persistence across restarts,
        # set CREDENTIAL_ENCRYPTION_KEY in .env (Fernet.generate_key() to create one).
        key = Fernet.generate_key().decode()
        security_logger.warning(
            "%s not set in environment — using an ephemeral key. Existing encrypted "
            "passwords will become unreadable after restart. Set this in .env for production.",
            _KEY_ENV,
        )
        os.environ[_KEY_ENV] = key
    return Fernet(key.encode() if isinstance(key, str) else key)


def encrypt_secret(plaintext: str) -> str:
    return _get_fernet().encrypt(plaintext.encode()).decode()


def decrypt_secret(ciphertext: str) -> str:
    return _get_fernet().decrypt(ciphertext.encode()).decode()


ALLOWED_BINARIES = {"chpasswd", "docker", "lxc", "pct"}


async def run_safe_subprocess(args: Sequence[str], timeout: int = 30) -> tuple[int, str, str]:
    """
    Execute a subprocess using an argument array — never a shell string.
    Refuses to run anything not in ALLOWED_BINARIES to prevent arbitrary
    command execution even if a caller is compromised or misused.
    """
    if not args:
        raise ValueError("No command supplied.")
    binary = os.path.basename(args[0])
    if binary not in ALLOWED_BINARIES:
        security_logger.warning("Blocked attempt to run disallowed binary: %s", binary)
        raise PermissionError(f"Execution of '{binary}' is not permitted.")

    security_logger.info("Executing: %s", " ".join(shlex.quote(a) for a in args))
    proc = await asyncio.create_subprocess_exec(
        *args, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
    )
    try:
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
    except asyncio.TimeoutError:
        proc.kill()
        raise TimeoutError(f"Command timed out after {timeout}s: {binary}")
    return proc.returncode or 0, stdout.decode(errors="replace"), stderr.decode(errors="replace")
