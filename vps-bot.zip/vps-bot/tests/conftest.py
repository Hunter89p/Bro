from __future__ import annotations

import asyncio
import sys
from pathlib import Path

import pytest
import pytest_asyncio

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from database import Database
from providers.base import ProviderError, VPSProvider, VPSResourceUsage, VPSSpec


@pytest_asyncio.fixture
async def test_db():
    db = Database(path=":memory:")
    await db.connect()
    yield db
    await db.close()


class FakeProvider(VPSProvider):
    """In-memory provider used for tests — no real Docker/LXC/Proxmox required."""

    name = "fake"

    def __init__(self, fail_create: bool = False):
        self.containers: dict[str, dict] = {}
        self.fail_create = fail_create
        self.host_cpu = 8
        self.host_ram = 16384
        self.host_disk = 500

    async def create_vps(self, spec: VPSSpec) -> dict:
        if self.fail_create:
            raise ProviderError("Simulated provider failure")
        self.containers[spec.container_name] = {"status": "running", "spec": spec}
        return {"ipv4": "10.0.0.5", "ipv6": None}

    async def start_vps(self, container_name: str) -> None:
        self.containers[container_name]["status"] = "running"

    async def stop_vps(self, container_name: str) -> None:
        self.containers[container_name]["status"] = "stopped"

    async def restart_vps(self, container_name: str) -> None:
        self.containers[container_name]["status"] = "running"

    async def delete_vps(self, container_name: str) -> None:
        self.containers.pop(container_name, None)

    async def reinstall_vps(self, container_name: str, spec: VPSSpec) -> dict:
        await self.delete_vps(container_name)
        return await self.create_vps(spec)

    async def get_status(self, container_name: str) -> str:
        c = self.containers.get(container_name)
        return c["status"] if c else "missing"

    async def get_resources(self, container_name: str):
        if container_name not in self.containers:
            return None
        return VPSResourceUsage(1.0, 100, 1024, 1, 10, 3600)

    async def get_ip(self, container_name: str):
        return ("10.0.0.5", None) if container_name in self.containers else (None, None)

    async def reset_password(self, container_name: str, username: str, new_password: str) -> None:
        if container_name not in self.containers:
            raise ProviderError("not found")

    async def host_capacity(self) -> dict:
        used_cpu = sum(c["spec"].cpu for c in self.containers.values())
        used_ram = sum(c["spec"].ram_mb for c in self.containers.values())
        used_disk = sum(c["spec"].disk_gb for c in self.containers.values())
        return {
            "cpu_total": self.host_cpu,
            "ram_total_mb": self.host_ram,
            "disk_total_gb": self.host_disk,
            "cpu_available": self.host_cpu - used_cpu,
            "ram_available_mb": self.host_ram - used_ram,
            "disk_available_gb": self.host_disk - used_disk,
        }


@pytest.fixture
def fake_provider():
    return FakeProvider()
