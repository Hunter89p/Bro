from utils.helpers import (
    generate_password,
    new_error_id,
    new_tx_id,
    validate_hostname,
)


def test_valid_hostnames():
    for h in ["my-server", "web01", "a", "x" * 63]:
        ok, err = validate_hostname(h)
        assert ok, f"expected {h!r} to be valid, got error: {err}"


def test_invalid_hostnames():
    cases = ["", "-bad", "bad-", "has spaces", "bad_underscore", "x" * 64, "localhost", "root"]
    for h in cases:
        ok, _ = validate_hostname(h)
        assert not ok, f"expected {h!r} to be invalid"


def test_generate_password_strength():
    pw = generate_password()
    assert len(pw) >= 12
    assert any(c.islower() for c in pw)
    assert any(c.isupper() for c in pw)
    assert any(c.isdigit() for c in pw)


def test_generate_password_unique():
    pw1 = generate_password()
    pw2 = generate_password()
    assert pw1 != pw2


def test_error_id_format():
    eid = new_error_id()
    assert eid.startswith("DEP-")
    assert len(eid) == 10


def test_tx_id_format():
    tx = new_tx_id()
    assert tx.startswith("TX-")
