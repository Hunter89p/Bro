import pytest

from services.deployment import DeploymentQueue, DeploymentRequest
from tests.conftest import FakeProvider

pytestmark = pytest.mark.asyncio


async def _get_plan(db, name="Basic"):
    plans = await db.list_plans()
    return dict(next(p for p in plans if p["name"] == name))


async def test_successful_deployment(test_db):
    provider = FakeProvider()
    queue = DeploymentQueue(test_db, provider)
    queue.start_workers()
    try:
        await test_db.get_or_create_user(1)
        await test_db.adjust_balance(1, 100, "topup")
        plan = await _get_plan(test_db)

        result = await queue.submit(
            DeploymentRequest(owner_id=1, hostname="myhost", os_image="Ubuntu 22.04", plan_row=plan)
        )
        assert result["ok"] is True
        assert "vps_id" in result

        user = await test_db.get_or_create_user(1)
        assert user["balance"] == pytest.approx(100 - plan["price"])

        vps = await test_db.get_vps(result["vps_id"])
        assert vps["status"] == "running"
    finally:
        await queue.stop_workers()


async def test_deployment_rolls_back_on_provider_failure(test_db):
    provider = FakeProvider(fail_create=True)
    queue = DeploymentQueue(test_db, provider)
    queue.start_workers()
    try:
        await test_db.get_or_create_user(1)
        await test_db.adjust_balance(1, 100, "topup")
        plan = await _get_plan(test_db)

        result = await queue.submit(
            DeploymentRequest(owner_id=1, hostname="myhost", os_image="Ubuntu 22.04", plan_row=plan)
        )
        assert result["ok"] is False
        assert "error_id" in result

        # balance must be refunded in full
        user = await test_db.get_or_create_user(1)
        assert user["balance"] == 100
    finally:
        await queue.stop_workers()


async def test_deployment_rejects_insufficient_balance(test_db):
    provider = FakeProvider()
    queue = DeploymentQueue(test_db, provider)
    queue.start_workers()
    try:
        await test_db.get_or_create_user(1)  # balance stays 0
        plan = await _get_plan(test_db)

        result = await queue.submit(
            DeploymentRequest(owner_id=1, hostname="myhost", os_image="Ubuntu 22.04", plan_row=plan)
        )
        assert result["ok"] is False
        assert "balance" in result["error"].lower()
    finally:
        await queue.stop_workers()


async def test_deployment_respects_host_capacity(test_db):
    provider = FakeProvider()
    provider.host_cpu = 1  # tiny host, Ultra plan (4 vCPU) shouldn't fit
    queue = DeploymentQueue(test_db, provider)
    queue.start_workers()
    try:
        await test_db.get_or_create_user(1)
        await test_db.adjust_balance(1, 1000, "topup")
        plan = await _get_plan(test_db, "Ultra")

        result = await queue.submit(
            DeploymentRequest(owner_id=1, hostname="myhost", os_image="Ubuntu 22.04", plan_row=plan)
        )
        assert result["ok"] is False
        assert "resources" in result["error"].lower()

        # balance untouched since it should fail before charging
        user = await test_db.get_or_create_user(1)
        assert user["balance"] == 1000
    finally:
        await queue.stop_workers()
