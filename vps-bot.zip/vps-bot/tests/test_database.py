import pytest

pytestmark = pytest.mark.asyncio


async def test_get_or_create_user(test_db):
    user = await test_db.get_or_create_user(123)
    assert user["discord_id"] == 123
    assert user["balance"] == 0

    same = await test_db.get_or_create_user(123)
    assert same["discord_id"] == 123


async def test_adjust_balance_atomic(test_db):
    await test_db.get_or_create_user(1)
    new_balance = await test_db.adjust_balance(1, 10.0, "topup")
    assert new_balance == 10.0

    new_balance = await test_db.adjust_balance(1, -3.0, "purchase")
    assert new_balance == 7.0


async def test_adjust_balance_insufficient_funds_raises(test_db):
    await test_db.get_or_create_user(1)
    with pytest.raises(ValueError):
        await test_db.adjust_balance(1, -5.0, "purchase")

    # balance must be unchanged after the failed attempt (rollback correctness)
    user = await test_db.get_or_create_user(1)
    assert user["balance"] == 0


async def test_default_plans_seeded(test_db):
    plans = await test_db.list_plans()
    names = {p["name"] for p in plans}
    assert {"Basic", "Pro", "Ultra"}.issubset(names)


async def test_port_allocation_no_duplicates(test_db):
    await test_db.get_or_create_user(1)
    async with test_db.transaction() as conn:
        vps_id = await test_db.create_vps_record(
            conn,
            {
                "owner_id": 1, "hostname": "h1", "container_name": "c1", "os": "Ubuntu 22.04",
                "plan_id": 1, "plan_name": "Basic", "cpu": 1, "ram_mb": 1024, "disk_gb": 10,
                "status": "provisioning", "provider": "fake",
                "created_at": "2026-01-01T00:00:00", "expires_at": "2026-02-01T00:00:00",
            },
        )
        port1 = await test_db.allocate_port(conn, vps_id)

    async with test_db.transaction() as conn:
        vps_id2 = await test_db.create_vps_record(
            conn,
            {
                "owner_id": 1, "hostname": "h2", "container_name": "c2", "os": "Ubuntu 22.04",
                "plan_id": 1, "plan_name": "Basic", "cpu": 1, "ram_mb": 1024, "disk_gb": 10,
                "status": "provisioning", "provider": "fake",
                "created_at": "2026-01-01T00:00:00", "expires_at": "2026-02-01T00:00:00",
            },
        )
        port2 = await test_db.allocate_port(conn, vps_id2)

    assert port1 != port2


async def test_duplicate_invite_detection(test_db):
    first = await test_db.record_invite(inviter_id=1, invitee_id=2)
    second = await test_db.record_invite(inviter_id=1, invitee_id=2)
    assert first is True
    assert second is False
