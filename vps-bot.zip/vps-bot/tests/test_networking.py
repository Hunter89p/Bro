from services.networking import validate_port


def test_privileged_ports_rejected():
    ok, err = validate_port(80)
    assert not ok
    assert "privileged" in err.lower()


def test_out_of_configured_range_rejected():
    ok, _ = validate_port(1025)  # below default PORT_RANGE_START (20000)
    assert not ok


def test_valid_port_in_range_accepted():
    ok, _ = validate_port(21000)
    assert ok


def test_out_of_bounds_rejected():
    ok, _ = validate_port(70000)
    assert not ok
    ok, _ = validate_port(0)
    assert not ok
