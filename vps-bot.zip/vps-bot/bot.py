"""
bot.py
Entrypoint. Wires together config, database, the selected provider, the
deployment queue, and the billing background task, then loads all cogs.
"""
from __future__ import annotations

import asyncio
import sys

import discord
from discord import app_commands
from discord.ext import commands, tasks

from config import settings
from database import db as database_instance
from providers.base import ProviderError, get_provider
from services.billing import BillingService
from services.deployment import DeploymentQueue
from utils import embeds
from utils.helpers import new_error_id
from utils.logger import bot_logger, error_logger, security_logger

INITIAL_COGS = [
    "cogs.user",
    "cogs.vps",
    "cogs.billing",
    "cogs.economy",
    "cogs.payments",
    "cogs.admin",
]


class VPSBot(commands.Bot):
    def __init__(self) -> None:
        intents = discord.Intents.default()
        intents.members = True
        intents.message_content = settings.enable_prefix_commands
        super().__init__(
            command_prefix=settings.command_prefix if settings.enable_prefix_commands else "\u0000",
            intents=intents,
        )
        self.settings = settings
        self.db = database_instance
        self.provider = None
        self.deployment_queue: DeploymentQueue | None = None
        self.billing_service: BillingService | None = None

    async def setup_hook(self) -> None:
        problems = settings.validate()
        for p in problems:
            bot_logger.warning("Config problem: %s", p)

        await self.db.connect()

        try:
            self.provider = get_provider(settings.provider_type)
        except ProviderError as exc:
            error_logger.critical("Failed to initialize provider: %s", exc)
            raise

        self.deployment_queue = DeploymentQueue(self.db, self.provider)
        self.deployment_queue.start_workers()
        self.billing_service = BillingService(self.db, self.provider, self)

        for cog in INITIAL_COGS:
            try:
                await self.load_extension(cog)
                bot_logger.info("Loaded cog: %s", cog)
            except Exception as exc:  # noqa: BLE001
                error_logger.exception("Failed loading cog %s: %s", cog, exc)

        if settings.guild_id:
            guild = discord.Object(id=settings.guild_id)
            self.tree.copy_global_to(guild=guild)
            await self.tree.sync(guild=guild)
            bot_logger.info("Synced commands to guild %s", settings.guild_id)
        else:
            await self.tree.sync()
            bot_logger.info("Synced global commands (may take up to 1h to propagate).")

        self.billing_cycle.start()

    async def on_ready(self) -> None:
        bot_logger.info("Logged in as %s (%s)", self.user, self.user.id if self.user else "?")
        await self.change_presence(activity=discord.Game(name="/deploy to launch a VPS"))

    @tasks.loop(minutes=15)
    async def billing_cycle(self) -> None:
        try:
            await self.billing_service.run_cycle()
        except Exception as exc:  # noqa: BLE001
            error_logger.exception("Billing cycle error: %s", exc)

    @billing_cycle.before_loop
    async def before_billing_cycle(self) -> None:
        await self.wait_until_ready()

    async def close(self) -> None:
        if self.deployment_queue:
            await self.deployment_queue.stop_workers()
        await self.db.close()
        await super().close()

    async def on_command_error(self, ctx: commands.Context, error: commands.CommandError) -> None:
        error_logger.exception("Prefix command error: %s", error)

    async def on_app_command_error(
        self, interaction: discord.Interaction, error: app_commands.AppCommandError
    ) -> None:
        if isinstance(error, app_commands.CheckFailure):
            security_logger.warning("Check failure for %s: %s", interaction.user.id, error)
            payload = embeds.error_embed("Not authorized", "You can't use this command.")
        elif isinstance(error, app_commands.CommandOnCooldown):
            payload = embeds.error_embed("Slow down", f"Try again in {error.retry_after:.0f}s.")
        else:
            eid = new_error_id()
            error_logger.exception("Unhandled app command error [%s]: %s", eid, error)
            payload = embeds.error_embed("Something went wrong", "Please try again later.", error_id=eid)

        try:
            if interaction.response.is_done():
                await interaction.followup.send(embed=payload, ephemeral=True)
            else:
                await interaction.response.send_message(embed=payload, ephemeral=True)
        except discord.HTTPException:
            pass


async def main() -> None:
    if not settings.discord_token:
        print("DISCORD_TOKEN is not set. Copy .env.example to .env and fill it in.", file=sys.stderr)
        sys.exit(1)

    bot = VPSBot()
    async with bot:
        await bot.start(settings.discord_token)


if __name__ == "__main__":
    asyncio.run(main())
