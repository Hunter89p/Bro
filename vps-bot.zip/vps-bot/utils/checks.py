"""
utils/checks.py
Permission + cooldown helpers. Admin authorization is always re-verified
server-side against config.settings.admin_ids — Discord IDs coming from
user input (e.g. /admin addbalance @someone) are never trusted for the
*caller's own* permission, only as the *target* of an action.
"""
from __future__ import annotations

import time
from collections import defaultdict

import discord
from discord import app_commands

from config import settings


def is_admin(user_id: int) -> bool:
    return user_id in settings.admin_ids


def admin_only():
    async def predicate(interaction: discord.Interaction) -> bool:
        if not is_admin(interaction.user.id):
            raise app_commands.CheckFailure("You are not authorized to use this command.")
        return True

    return app_commands.check(predicate)


class CooldownBucket:
    """Simple in-memory sliding-window rate limiter (per user, per action)."""

    def __init__(self) -> None:
        self._hits: dict[tuple[int, str], list[float]] = defaultdict(list)

    def check(self, user_id: int, action: str, max_hits: int, window_seconds: int) -> tuple[bool, float]:
        key = (user_id, action)
        now = time.monotonic()
        window_start = now - window_seconds
        hits = [t for t in self._hits[key] if t >= window_start]
        self._hits[key] = hits
        if len(hits) >= max_hits:
            retry_after = window_seconds - (now - hits[0])
            return False, max(retry_after, 0)
        hits.append(now)
        return True, 0.0


cooldowns = CooldownBucket()
