"""
utils/helpers.py
Small stateless helpers shared across the codebase.
"""
from __future__ import annotations

import re
import secrets
import string
import uuid
from datetime import datetime, timezone

HOSTNAME_RE = re.compile(r"^(?!-)[A-Za-z0-9-]{1,63}(?<!-)$")


def now_utc() -> datetime:
    return datetime.now(timezone.utc)


def validate_hostname(hostname: str) -> tuple[bool, str]:
    """Validate a user-supplied hostname. Returns (is_valid, error_message)."""
    if not hostname:
        return False, "Hostname cannot be empty."
    if len(hostname) > 63:
        return False, "Hostname must be 63 characters or fewer."
    if not HOSTNAME_RE.match(hostname):
        return False, "Hostname may only contain letters, digits, and hyphens (no leading/trailing hyphen)."
    reserved = {"localhost", "root", "admin", "docker", "docker0"}
    if hostname.lower() in reserved:
        return False, f"'{hostname}' is a reserved name."
    return True, ""


def generate_password(length: int = 20) -> str:
    """Cryptographically secure random password with mixed character classes."""
    if length < 12:
        length = 12
    alphabet = string.ascii_letters + string.digits + "!@#$%^&*()-_=+"
    while True:
        pw = "".join(secrets.choice(alphabet) for _ in range(length))
        if (
            any(c.islower() for c in pw)
            and any(c.isupper() for c in pw)
            and any(c.isdigit() for c in pw)
            and any(c in "!@#$%^&*()-_=+" for c in pw)
        ):
            return pw


def generate_container_name(prefix: str = "vps") -> str:
    return f"{prefix}-{uuid.uuid4().hex[:10]}"


def new_error_id() -> str:
    """Short human-shareable error reference, e.g. DEP-8F31A."""
    return f"DEP-{secrets.token_hex(3).upper()}"


def new_tx_id() -> str:
    return f"TX-{uuid.uuid4().hex[:12].upper()}"


def format_bytes_gb(gb: float) -> str:
    return f"{gb:.0f} GB" if gb == int(gb) else f"{gb:.1f} GB"


def mask_password_hint(password: str) -> str:
    """Never used for real credential display — only for logs/audit previews."""
    if len(password) <= 4:
        return "*" * len(password)
    return password[:2] + "*" * (len(password) - 4) + password[-2:]
