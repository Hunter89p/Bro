"""
utils/embeds.py
Centralized embed builders so every command shares the same look and feel.
"""
from __future__ import annotations

from datetime import datetime
from typing import Optional

import discord

COLOR_SUCCESS = 0x57F287
COLOR_ERROR = 0xED4245
COLOR_WARNING = 0xFEE75C
COLOR_INFO = 0x5865F2
COLOR_NEUTRAL = 0x2B2D31


def success_embed(title: str, description: str = "") -> discord.Embed:
    e = discord.Embed(title=f"✅ {title}", description=description, color=COLOR_SUCCESS)
    e.timestamp = datetime.utcnow()
    return e


def error_embed(title: str, description: str = "", error_id: Optional[str] = None) -> discord.Embed:
    e = discord.Embed(title=f"❌ {title}", description=description, color=COLOR_ERROR)
    if error_id:
        e.add_field(name="Reference", value=f"`{error_id}`", inline=False)
    e.timestamp = datetime.utcnow()
    return e


def warning_embed(title: str, description: str = "") -> discord.Embed:
    e = discord.Embed(title=f"⚠️ {title}", description=description, color=COLOR_WARNING)
    e.timestamp = datetime.utcnow()
    return e


def info_embed(title: str, description: str = "") -> discord.Embed:
    e = discord.Embed(title=f"ℹ️ {title}", description=description, color=COLOR_INFO)
    e.timestamp = datetime.utcnow()
    return e


def vps_info_embed(vps: dict) -> discord.Embed:
    e = discord.Embed(
        title=f"🖥️ {vps['hostname']}",
        description=f"VPS `#{vps['id']}`",
        color=COLOR_INFO if vps["status"] == "running" else COLOR_NEUTRAL,
    )
    status_emoji = {"running": "🟢", "stopped": "🔴", "suspended": "🟡", "provisioning": "🔵"}.get(
        vps["status"], "⚪"
    )
    e.add_field(name="Status", value=f"{status_emoji} {vps['status'].title()}", inline=True)
    e.add_field(name="Plan", value=vps["plan_name"], inline=True)
    e.add_field(name="OS", value=vps["os"], inline=True)
    e.add_field(name="CPU", value=f"{vps['cpu']} vCPU", inline=True)
    e.add_field(name="RAM", value=f"{vps['ram_mb']} MB", inline=True)
    e.add_field(name="Disk", value=f"{vps['disk_gb']} GB", inline=True)
    e.add_field(name="IPv4", value=vps.get("ipv4") or "—", inline=True)
    e.add_field(name="IPv6", value=vps.get("ipv6") or "—", inline=True)
    e.add_field(name="SSH Port", value=str(vps.get("ssh_port") or "—"), inline=True)
    e.add_field(name="Created", value=vps["created_at"], inline=True)
    e.add_field(name="Expires", value=vps["expires_at"], inline=True)
    e.add_field(name="Owner", value=f"<@{vps['owner_id']}>", inline=True)
    e.set_footer(text="Use /ssh for connection credentials (sent privately).")
    return e


def deployment_progress_embed(step: str, done_steps: list[str]) -> discord.Embed:
    lines = [f"✅ {s}" for s in done_steps]
    lines.append(f"⏳ {step}")
    e = discord.Embed(title="🚀 Deploying your VPS", description="\n".join(lines), color=COLOR_INFO)
    return e


def plan_select_embed(plans: list[dict]) -> discord.Embed:
    e = discord.Embed(title="🚀 VPS Deployment — Choose a plan", color=COLOR_INFO)
    for p in plans:
        e.add_field(
            name=p["name"],
            value=(
                f"**{p['cpu']}** vCPU | **{p['ram_mb']} MB** RAM | **{p['disk_gb']} GB** Disk\n"
                f"💰 {p['price']:.2f} credits / {p['duration_days']}d"
            ),
            inline=False,
        )
    return e
