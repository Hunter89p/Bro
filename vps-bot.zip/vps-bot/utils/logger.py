"""
utils/logger.py
Sets up separate rotating log files: bot, deployment, error, security, admin.
A redaction filter strips anything that looks like a token/secret before
it ever hits disk.
"""
from __future__ import annotations

import logging
import re
from logging.handlers import RotatingFileHandler
from pathlib import Path

from config import LOG_DIR, settings

_SECRET_PATTERNS = [
    re.compile(r"([A-Za-z0-9_\-]{24}\.[A-Za-z0-9_\-]{6}\.[A-Za-z0-9_\-]{27,})"),  # discord token shape
    re.compile(r"(password\s*[:=]\s*)\S+", re.IGNORECASE),
    re.compile(r"(token\s*[:=]\s*)\S+", re.IGNORECASE),
    re.compile(r"(secret\s*[:=]\s*)\S+", re.IGNORECASE),
    re.compile(r"(api[_-]?key\s*[:=]\s*)\S+", re.IGNORECASE),
]


class RedactingFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        try:
            msg = record.getMessage()
        except Exception:
            return True
        redacted = msg
        for pattern in _SECRET_PATTERNS:
            redacted = pattern.sub(lambda m: (m.group(1) if m.lastindex else "") + "[REDACTED]", redacted)
        record.msg = redacted
        record.args = ()
        return True


def _make_handler(filename: str) -> RotatingFileHandler:
    handler = RotatingFileHandler(
        LOG_DIR / filename, maxBytes=5_000_000, backupCount=5, encoding="utf-8"
    )
    handler.setFormatter(
        logging.Formatter("%(asctime)s | %(levelname)-8s | %(name)s | %(message)s")
    )
    handler.addFilter(RedactingFilter())
    return handler


def get_logger(name: str, log_file: str = "bot.log") -> logging.Logger:
    logger = logging.getLogger(name)
    if logger.handlers:
        return logger  # already configured
    logger.setLevel(settings.log_level)
    logger.addHandler(_make_handler(log_file))

    console = logging.StreamHandler()
    console.setFormatter(logging.Formatter("%(levelname)-8s %(name)s: %(message)s"))
    console.addFilter(RedactingFilter())
    logger.addHandler(console)

    logger.propagate = False
    return logger


bot_logger = get_logger("bot", "bot.log")
deployment_logger = get_logger("deployment", "deployment.log")
error_logger = get_logger("error", "error.log")
security_logger = get_logger("security", "security.log")
admin_logger = get_logger("admin", "admin.log")
