# VPS Bot — Discord VPS Deployment & Management Bot

A modular Discord bot that lets users deploy, manage, and pay for
"VPS" instances (Docker containers by default) directly from Discord —
plans, billing, an economy system, and full admin tooling included.

> **Provider status:** the **Docker** backend is fully implemented and
> works out of the box against any Docker Engine. LXC/LXD and Proxmox
> are shipped as clean, documented interface stubs (`providers/lxc.py`,
> `providers/proxmox.py`) — they raise a clear error until someone
> implements them against a real host, rather than pretending to work.

---

## 1. Installing Python

You need **Python 3.11+**.

```bash
python3 --version   # should print 3.11.x or higher
```

If it doesn't, install it from https://www.python.org/downloads/ or via
your OS package manager (`apt install python3.11`, `brew install python@3.11`, etc).

## 2. Creating a virtual environment

```bash
cd vps-bot
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
```

## 3. Installing requirements

```bash
pip install -r requirements.txt
```

This installs `discord.py`, `aiosqlite`, the `docker` SDK, `cryptography`,
`psutil`, and the test tooling.

## 4. Creating `.env`

```bash
cp .env.example .env
```

Then fill in at minimum:

| Variable | Required | Notes |
|---|---|---|
| `DISCORD_TOKEN` | ✅ | From the Discord Developer Portal |
| `ADMIN_IDS` | ✅ | Comma-separated Discord user IDs, e.g. `123,456` |
| `PROVIDER_TYPE` | ✅ | `docker` (only fully-working option today) |
| `CREDENTIAL_ENCRYPTION_KEY` | recommended | See below |
| `GUILD_ID` | recommended for dev | Instant command sync to one server |

Generate an encryption key for stored SSH passwords:

```bash
python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
```

Paste the output into `CREDENTIAL_ENCRYPTION_KEY`. If you skip this, the
bot generates a throwaway key each run — passwords stored before a
restart become unreadable, and `/ssh-reset` becomes the recovery path.

## 5. Setting Discord bot permissions

In the [Discord Developer Portal](https://discord.com/developers/applications):

1. Create an application → Bot tab → **Reset Token**, copy it into `DISCORD_TOKEN`.
2. Under **Privileged Gateway Intents**, enable **Server Members Intent**
   (required for `/admin users`, DMs, invite tracking).
3. Under **OAuth2 → URL Generator**, select scopes `bot` and
   `applications.commands`, and permissions: Send Messages, Embed Links,
   Use Slash Commands, Manage Messages (for cleanup), Attach Files.
4. Invite the bot to your server with the generated URL.

## 6. Database initialization

Nothing to run manually — `Database.connect()` creates
`data/bot.db` and the full schema (including the three default plans:
Basic/Pro/Ultra) automatically on first launch.

To reset the database, stop the bot and delete `data/bot.db`.

## 7. Provider configuration (Docker)

```bash
# Docker Engine must be installed and running on the host:
docker --version
sudo systemctl status docker

# The bot user needs permission to talk to the Docker socket:
sudo usermod -aG docker $USER   # then log out/in
```

Leave `DOCKER_HOST=unix:///var/run/docker.sock` unless Docker is remote
(e.g. `DOCKER_HOST=tcp://1.2.3.4:2375` with TLS configured — see Docker's
own docs on securing the remote API before doing this in production).

The bot creates an isolated bridge network (`vpsbot_net` by default) on
first run and attaches every deployed container to it.

**Known limitation:** per-container disk quotas aren't enforced by the
Docker backend out of the box (overlay2 doesn't support per-container
quotas without extra host configuration — XFS project quotas or
`--storage-opt size=` on a `devicemapper`/`zfs` graph driver would add
this). Disk figures in `/vpsinfo` reflect the configured plan, not a
live enforced limit, until you wire that up.

## 8. Starting the bot

```bash
python bot.py
```

You should see `Logged in as <BotName>` and, if `GUILD_ID` is set,
slash commands appear in that server within seconds (global sync can
take up to an hour on first deploy).

## 9. Troubleshooting

| Symptom | Likely cause |
|---|---|
| Bot logs in but no slash commands appear | Global sync can take up to 1h — set `GUILD_ID` for instant sync during development |
| `PermissionError` connecting to Docker | Bot's user isn't in the `docker` group, or socket path is wrong |
| `/deploy` always says "insufficient host resources" | `HOST_MAX_CPU`/`HOST_MAX_RAM_MB` in `.env` set too low, or containers from a previous crash weren't cleaned up — check `docker ps -a` |
| SSH login fails after `/ssh` | Container may still be starting; check `docker logs <container_name>` |
| `/admin` commands say "Not authorized" for you | Your Discord user ID isn't in `ADMIN_IDS` — IDs, not usernames |
| Passwords unreadable after a restart | `CREDENTIAL_ENCRYPTION_KEY` wasn't set, so a new key was generated — use `/ssh-reset` per VPS |

Logs are split under `logs/`: `bot.log`, `deployment.log`, `error.log`,
`security.log`, `admin.log`. Tokens/passwords/secrets are redacted
before being written, even if a log line accidentally contains one.

## 10. Production deployment

- **Process management:** run under `systemd`, `supervisord`, or a
  Docker container of the bot itself (with the host's Docker socket
  bind-mounted in — be aware this grants the bot host-level Docker
  access, so run it on a dedicated host or namespace it carefully).
- **Database:** SQLite is fine for a single-instance bot at moderate
  scale. For horizontal scale or heavier concurrent write load, point
  `DATABASE_URL` at PostgreSQL and swap `database.py`'s connection layer
  for `asyncpg`/`databases` — the schema and query shapes were written
  to translate directly.
- **Backups:** `/admin backup` snapshots `data/bot.db` into a timestamped
  copy in the same directory; ship those off-host on a cron schedule.
- **Secrets:** never commit `.env`. Use your platform's secret manager
  (systemd `EnvironmentFile=`, Docker secrets, Vault, etc.) in real
  production rather than a bare `.env` file on disk.
- **Reverse proxy / firewall:** the configured `PORT_RANGE_START`–`END`
  is opened per-VPS for SSH; put a firewall in front of the host and
  only allow that range, not the whole machine.
- **Monitoring:** `/status` exposes latency and host CPU/RAM/disk;
  wire log shipping (e.g. Vector, Filebeat) on `logs/*.log` for
  centralized monitoring/alerting.

---

## Running tests

```bash
pip install -r requirements.txt   # includes pytest + pytest-asyncio
pytest -v
```

Tests cover: database transactions & rollback, balance atomicity,
duplicate-invite detection, port allocation, full deployment success/
failure/rollback paths, host-capacity enforcement, hostname/password
validation, and port-range validation. They run against an in-memory
SQLite database and a `FakeProvider` (see `tests/conftest.py`) — no real
Docker daemon required to run the suite.

## Command reference

| Command | Description |
|---|---|
| `/deploy` | Guided VPS deployment (OS → plan → hostname) |
| `/buy` | Alias for `/deploy` |
| `/plans` | List available plans |
| `/vps` | List & manage your VPS instances with buttons |
| `/vpsctl start\|stop\|restart\|delete\|reinstall <id>` | Direct lifecycle commands |
| `/vpsinfo <id>` | Full VPS details |
| `/ssh <id>` / `/ssh-reset <id>` | Ephemeral SSH credentials |
| `/balance` / `/credits` | Check balance |
| `/daily` | Claim daily credits |
| `/transfer <user> <amount>` | Send credits to another user |
| `/invite` | Invite reward info |
| `/addbalance <amount>` | Start a payment (manual provider by default) |
| `/renew <id>` | Extend a VPS's expiry |
| `/upgrade <id> <plan>` | Move a VPS to a higher plan |
| `/billing` | Your billing summary |
| `/status` | Bot & host status |
| `/admin ...` | Full admin toolkit (balances, force deploy/delete, suspend, stats, broadcast, maintenance, plans, limits, backups, payment confirmation) |

## Architecture

```
Discord slash command
        │
        ▼
   cogs/*.py  ── permission/cooldown checks, UI (embeds/buttons/modals)
        │
        ▼
services/deployment.py ── queue + workers, transactional rollback
services/billing.py    ── expiry warnings, suspension, grace period
services/payments.py   ── payment provider abstraction
services/security.py   ── credential encryption, safe subprocess exec
services/networking.py ── port validation
        │
        ▼
providers/base.py (VPSProvider interface)
        │
        ├── providers/docker.py    (fully implemented)
        ├── providers/lxc.py       (interface stub)
        └── providers/proxmox.py   (interface stub)
        │
        ▼
database.py (aiosqlite, transactional, indexed, foreign keys)
```

Swapping providers or the payment gateway never touches `cogs/` or
`services/deployment.py` — they only depend on the abstract interfaces
in `providers/base.py` and `services/payments.py`.
