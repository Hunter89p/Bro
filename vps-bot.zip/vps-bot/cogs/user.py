"""
cogs/user.py
/deploy, /vpsinfo, /ssh, /ssh-reset, /plans — the core user-facing
deployment flow and information commands.
"""
from __future__ import annotations

import discord
from discord import app_commands
from discord.ext import commands

from utils import embeds
from utils.checks import cooldowns
from utils.helpers import validate_hostname, generate_password
from services.deployment import DeploymentRequest
from services.security import encrypt_secret
from services.networking import build_ssh_command
from utils.logger import bot_logger, security_logger

OS_CHOICES = ["Ubuntu 22.04", "Ubuntu 24.04", "Debian 12"]


class OSSelect(discord.ui.Select):
    def __init__(self):
        options = [discord.SelectOption(label=o, value=o) for o in OS_CHOICES]
        super().__init__(placeholder="Select an operating system", options=options, min_values=1, max_values=1)

    async def callback(self, interaction: discord.Interaction):
        self.view.chosen_os = self.values[0]
        for child in self.view.children:
            child.disabled = True
        await interaction.response.edit_message(
            content=f"OS selected: **{self.values[0]}**. Now choose a plan below.", view=self.view
        )
        self.view.stop()


class OSSelectView(discord.ui.View):
    def __init__(self, timeout: float = 60):
        super().__init__(timeout=timeout)
        self.chosen_os: str | None = None
        self.add_item(OSSelect())


class PlanSelect(discord.ui.Select):
    def __init__(self, plans):
        self._plans = {str(p["id"]): p for p in plans}
        options = [
            discord.SelectOption(
                label=f"{p['name']} — {p['cpu']} vCPU / {p['ram_mb']}MB / {p['disk_gb']}GB",
                description=f"{p['price']:.2f} credits / {p['duration_days']}d",
                value=str(p["id"]),
            )
            for p in plans
        ]
        super().__init__(placeholder="Select a plan", options=options, min_values=1, max_values=1)

    async def callback(self, interaction: discord.Interaction):
        self.view.chosen_plan = self._plans[self.values[0]]
        for child in self.view.children:
            child.disabled = True
        await interaction.response.edit_message(
            content=f"Plan selected: **{self.view.chosen_plan['name']}**.", view=self.view
        )
        self.view.stop()


class PlanSelectView(discord.ui.View):
    def __init__(self, plans, timeout: float = 60):
        super().__init__(timeout=timeout)
        self.chosen_plan = None
        self.add_item(PlanSelect(plans))


class HostnameModal(discord.ui.Modal, title="Choose a hostname"):
    hostname = discord.ui.TextInput(label="Hostname", placeholder="my-server", max_length=63)

    def __init__(self):
        super().__init__()
        self.value: str | None = None

    async def on_submit(self, interaction: discord.Interaction):
        self.value = str(self.hostname)
        await interaction.response.defer(ephemeral=True)
        self.stop()


class UserCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @property
    def db(self):
        return self.bot.db

    @property
    def provider(self):
        return self.bot.provider

    @property
    def queue(self):
        return self.bot.deployment_queue

    # ---------------- /status ----------------

    @app_commands.command(name="status", description="Show bot and platform status.")
    async def status(self, interaction: discord.Interaction):
        import time
        import psutil

        latency_ms = round(self.bot.latency * 1000)
        cpu = psutil.cpu_percent(interval=0.2)
        mem = psutil.virtual_memory()
        disk = psutil.disk_usage("/")
        vps_rows = await self.db.list_all_vps()
        active_deployments = self.queue._queue.qsize() if hasattr(self.queue, "_queue") else 0

        e = embeds.info_embed("🩺 Bot Status")
        e.add_field(name="Latency", value=f"{latency_ms}ms", inline=True)
        e.add_field(name="Host CPU", value=f"{cpu}%", inline=True)
        e.add_field(name="Host RAM", value=f"{mem.percent}%", inline=True)
        e.add_field(name="Host Disk", value=f"{disk.percent}%", inline=True)
        e.add_field(name="Total VPS", value=str(len(vps_rows)), inline=True)
        e.add_field(name="Queued Deployments", value=str(active_deployments), inline=True)
        e.add_field(name="Provider", value=self.provider.name, inline=True)
        e.add_field(name="Database", value="🟢 Connected", inline=True)
        await interaction.response.send_message(embed=e)

    # ---------------- /plans ----------------

    @app_commands.command(name="plans", description="Show available VPS plans.")
    async def plans_cmd(self, interaction: discord.Interaction):
        plans = await self.db.list_plans()
        if not plans:
            await interaction.response.send_message(embed=embeds.warning_embed("No plans configured."))
            return
        await interaction.response.send_message(embed=embeds.plan_select_embed([dict(p) for p in plans]))

    # ---------------- /deploy ----------------

    @app_commands.command(name="deploy", description="Deploy a new VPS.")
    async def deploy(self, interaction: discord.Interaction):
        user_id = interaction.user.id

        ok, retry_after = cooldowns.check(user_id, "deploy", max_hits=3, window_seconds=3600)
        if not ok:
            await interaction.response.send_message(
                embed=embeds.error_embed(
                    "Rate limited", f"You can deploy again in {int(retry_after)}s (max 3/hour)."
                ),
                ephemeral=True,
            )
            return

        user = await self.db.get_or_create_user(user_id)
        if user["is_suspended"]:
            await interaction.response.send_message(
                embed=embeds.error_embed("Account suspended", "Contact an admin for details."), ephemeral=True
            )
            return

        existing = await self.db.count_user_vps(user_id)
        if existing >= user["vps_limit"]:
            await interaction.response.send_message(
                embed=embeds.error_embed(
                    "VPS limit reached", f"You already have {existing}/{user['vps_limit']} VPS instances."
                ),
                ephemeral=True,
            )
            return

        # 1. OS selection
        os_view = OSSelectView()
        await interaction.response.send_message("Select an operating system:", view=os_view, ephemeral=True)
        await os_view.wait()
        if not os_view.chosen_os:
            await interaction.followup.send(embed=embeds.error_embed("Timed out", "No OS selected."), ephemeral=True)
            return

        # 2. Plan selection
        plans = [dict(p) for p in await self.db.list_plans()]
        if not plans:
            await interaction.followup.send(embed=embeds.error_embed("No plans configured."), ephemeral=True)
            return
        plan_view = PlanSelectView(plans)
        await interaction.followup.send("Select a plan:", view=plan_view, ephemeral=True)
        await plan_view.wait()
        if not plan_view.chosen_plan:
            await interaction.followup.send(embed=embeds.error_embed("Timed out", "No plan selected."), ephemeral=True)
            return
        plan = plan_view.chosen_plan

        if user["balance"] < plan["price"]:
            await interaction.followup.send(
                embed=embeds.error_embed(
                    "Insufficient balance",
                    f"This plan costs {plan['price']:.2f} credits; your balance is {user['balance']:.2f}.",
                ),
                ephemeral=True,
            )
            return

        # 3. Hostname
        modal = HostnameModal()
        # Modals must be triggered from a component interaction; use a button prompt.
        prompt_view = discord.ui.View(timeout=60)
        button = discord.ui.Button(label="Enter hostname", style=discord.ButtonStyle.primary)

        async def _button_cb(btn_interaction: discord.Interaction):
            await btn_interaction.response.send_modal(modal)

        button.callback = _button_cb
        prompt_view.add_item(button)
        await interaction.followup.send("Click below to enter a hostname:", view=prompt_view, ephemeral=True)
        await prompt_view.wait()

        if not modal.value:
            await interaction.followup.send(embed=embeds.error_embed("Timed out", "No hostname entered."), ephemeral=True)
            return

        valid, err = validate_hostname(modal.value)
        if not valid:
            await interaction.followup.send(embed=embeds.error_embed("Invalid hostname", err), ephemeral=True)
            return

        # 4. Deploy with live progress
        progress_msg = await interaction.followup.send(
            embed=embeds.deployment_progress_embed("Starting...", []), ephemeral=True, wait=True
        )
        done_steps: list[str] = []

        async def progress_cb(step: str):
            await progress_msg.edit(embed=embeds.deployment_progress_embed(step, done_steps))
            done_steps.append(step)

        request = DeploymentRequest(
            owner_id=user_id,
            hostname=modal.value,
            os_image=os_view.chosen_os,
            plan_row=plan,
            progress_cb=progress_cb,
        )
        result = await self.queue.submit(request)

        if not result["ok"]:
            await progress_msg.edit(
                embed=embeds.error_embed("Deployment Failed", result["error"], error_id=result.get("error_id"))
            )
            return

        success_embed = embeds.success_embed(
            "VPS Deployed!",
            f"`{modal.value}` (#{result['vps_id']}) is ready.\n"
            f"Use `/ssh {result['vps_id']}` to get your connection details.",
        )
        success_embed.add_field(name="IPv4", value=result.get("ipv4") or "—", inline=True)
        success_embed.add_field(name="SSH Port", value=str(result["ssh_port"]), inline=True)
        await progress_msg.edit(embed=success_embed)

    # ---------------- /vpsinfo ----------------

    @app_commands.command(name="vpsinfo", description="Show detailed info about a VPS.")
    @app_commands.describe(vps_id="The VPS ID")
    async def vpsinfo(self, interaction: discord.Interaction, vps_id: int):
        vps = await self.db.get_vps(vps_id)
        if not vps or vps["status"] == "deleted":
            await interaction.response.send_message(embed=embeds.error_embed("VPS not found."), ephemeral=True)
            return
        if vps["owner_id"] != interaction.user.id and interaction.user.id not in self.bot.settings.admin_ids:
            await interaction.response.send_message(embed=embeds.error_embed("Not your VPS."), ephemeral=True)
            return
        await interaction.response.send_message(embed=embeds.vps_info_embed(dict(vps)))

    # ---------------- /ssh ----------------

    @app_commands.command(name="ssh", description="Get SSH connection details for your VPS (ephemeral).")
    @app_commands.describe(vps_id="The VPS ID")
    async def ssh(self, interaction: discord.Interaction, vps_id: int):
        vps = await self.db.get_vps(vps_id)
        if not vps or vps["status"] == "deleted" or vps["owner_id"] != interaction.user.id:
            await interaction.response.send_message(embed=embeds.error_embed("VPS not found."), ephemeral=True)
            return
        if not vps["ssh_password_enc"]:
            await interaction.response.send_message(
                embed=embeds.error_embed("No credentials on file", "Try `/ssh-reset` to generate new ones."),
                ephemeral=True,
            )
            return
        from services.security import decrypt_secret

        password = decrypt_secret(vps["ssh_password_enc"])
        cmd = build_ssh_command(vps["ipv4"] or "pending", vps["ssh_port"], vps["ssh_username"])
        e = embeds.info_embed("🔐 SSH Connection Details", f"For `{vps['hostname']}` (#{vps_id})")
        e.add_field(name="Host", value=vps["ipv4"] or "pending", inline=True)
        e.add_field(name="Port", value=str(vps["ssh_port"]), inline=True)
        e.add_field(name="Username", value=vps["ssh_username"], inline=True)
        e.add_field(name="Password", value=f"||{password}||", inline=False)
        e.add_field(name="Command", value=f"```{cmd}```", inline=False)
        e.set_footer(text="This message is only visible to you.")
        await interaction.response.send_message(embed=e, ephemeral=True)
        security_logger.info("SSH credentials viewed: user=%s vps=%s", interaction.user.id, vps_id)

    @app_commands.command(name="ssh-reset", description="Reset the SSH password for your VPS.")
    @app_commands.describe(vps_id="The VPS ID")
    async def ssh_reset(self, interaction: discord.Interaction, vps_id: int):
        vps = await self.db.get_vps(vps_id)
        if not vps or vps["status"] == "deleted" or vps["owner_id"] != interaction.user.id:
            await interaction.response.send_message(embed=embeds.error_embed("VPS not found."), ephemeral=True)
            return
        await interaction.response.defer(ephemeral=True)
        new_password = generate_password()
        try:
            await self.provider.reset_password(vps["container_name"], vps["ssh_username"], new_password)
        except Exception as exc:  # noqa: BLE001
            from utils.helpers import new_error_id
            eid = new_error_id()
            bot_logger.error("ssh-reset failed [%s]: %s", eid, exc)
            await interaction.followup.send(
                embed=embeds.error_embed("Password reset failed", error_id=eid), ephemeral=True
            )
            return
        await self.db.update_vps(vps_id, ssh_password_enc=encrypt_secret(new_password))
        await self.db.log_audit(interaction.user.id, "ssh_reset", target=f"vps:{vps_id}")
        e = embeds.success_embed("Password reset", f"New password for `{vps['hostname']}`:")
        e.add_field(name="Password", value=f"||{new_password}||")
        await interaction.followup.send(embed=e, ephemeral=True)


async def setup(bot: commands.Bot):
    await bot.add_cog(UserCog(bot))
