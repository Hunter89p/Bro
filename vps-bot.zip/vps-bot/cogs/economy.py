"""
cogs/economy.py
/balance, /daily, /transfer, /invite — the credit economy. Abuse
prevention: cooldowns on daily/transfer, duplicate-invite detection at
the DB layer (UNIQUE constraint on invitee_id), and every balance change
goes through Database.adjust_balance so it's atomic and logged.
"""
from __future__ import annotations

from datetime import timedelta

import discord
from discord import app_commands
from discord.ext import commands

from utils import embeds
from utils.checks import cooldowns
from utils.helpers import now_utc

DAILY_AMOUNT = 2.0
INVITE_REWARD = 5.0


class EconomyCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @property
    def db(self):
        return self.bot.db

    @app_commands.command(name="balance", description="Check your credit balance.")
    async def balance(self, interaction: discord.Interaction):
        user = await self.db.get_or_create_user(interaction.user.id)
        await interaction.response.send_message(
            embed=embeds.info_embed("💰 Balance", f"You have **{user['balance']:.2f}** credits."),
            ephemeral=True,
        )

    # alias requested in spec ("/credits")
    @app_commands.command(name="credits", description="Check your credit balance.")
    async def credits(self, interaction: discord.Interaction):
        await self.balance.callback(self, interaction)

    @app_commands.command(name="daily", description="Claim your daily credit reward.")
    async def daily(self, interaction: discord.Interaction):
        user = await self.db.get_or_create_user(interaction.user.id)
        if user["last_daily_at"]:
            from datetime import datetime

            last = datetime.fromisoformat(user["last_daily_at"])
            if now_utc() - last < timedelta(hours=24):
                remaining = timedelta(hours=24) - (now_utc() - last)
                hrs = int(remaining.total_seconds() // 3600)
                mins = int((remaining.total_seconds() % 3600) // 60)
                await interaction.response.send_message(
                    embed=embeds.warning_embed("Already claimed", f"Next claim available in {hrs}h {mins}m."),
                    ephemeral=True,
                )
                return
        new_balance = await self.db.adjust_balance(interaction.user.id, DAILY_AMOUNT, "daily", "Daily reward")
        await self.db._conn.execute(
            "UPDATE users SET last_daily_at = ? WHERE discord_id = ?",
            (now_utc().isoformat(), interaction.user.id),
        )
        await self.db._conn.commit()
        await interaction.response.send_message(
            embed=embeds.success_embed(
                "Daily reward claimed!", f"+{DAILY_AMOUNT:.2f} credits. New balance: {new_balance:.2f}."
            ),
            ephemeral=True,
        )

    @app_commands.command(name="transfer", description="Transfer credits to another user.")
    @app_commands.describe(user="Recipient", amount="Amount to transfer")
    async def transfer(self, interaction: discord.Interaction, user: discord.User, amount: float):
        if amount <= 0:
            await interaction.response.send_message(embed=embeds.error_embed("Amount must be positive."), ephemeral=True)
            return
        if user.id == interaction.user.id:
            await interaction.response.send_message(embed=embeds.error_embed("You can't transfer to yourself."), ephemeral=True)
            return
        if user.bot:
            await interaction.response.send_message(embed=embeds.error_embed("Can't transfer to a bot."), ephemeral=True)
            return

        ok, retry_after = cooldowns.check(interaction.user.id, "transfer", max_hits=5, window_seconds=3600)
        if not ok:
            await interaction.response.send_message(
                embed=embeds.error_embed("Rate limited", f"Try again in {int(retry_after)}s."), ephemeral=True
            )
            return

        await self.db.get_or_create_user(user.id)
        try:
            await self.db.adjust_balance(interaction.user.id, -amount, "transfer_out", f"To {user.id}")
        except ValueError:
            await interaction.response.send_message(embed=embeds.error_embed("Insufficient balance."), ephemeral=True)
            return
        await self.db.adjust_balance(user.id, amount, "transfer_in", f"From {interaction.user.id}")
        await interaction.response.send_message(
            embed=embeds.success_embed("Transfer complete", f"Sent {amount:.2f} credits to {user.mention}.")
        )

    @app_commands.command(name="invite", description="Get your invite reward status.")
    async def invite(self, interaction: discord.Interaction):
        await interaction.response.send_message(
            embed=embeds.info_embed(
                "🎉 Invite Rewards",
                f"Invite friends and earn **{INVITE_REWARD:.2f}** credits per verified join "
                "(rewarded automatically once, duplicate joins are ignored).",
            ),
            ephemeral=True,
        )

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        """Best-effort invite tracking. Requires the Members + Invites intents and
        MANAGE_GUILD permission for the bot to diff invite uses accurately; this is a
        minimal illustrative hook — production invite tracking should snapshot invite
        `uses` counts before/after join to identify the actual inviter."""
        pass


async def setup(bot: commands.Bot):
    await bot.add_cog(EconomyCog(bot))
