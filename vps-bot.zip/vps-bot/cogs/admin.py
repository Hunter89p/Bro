"""
cogs/admin.py
/admin command group. Every command is guarded by utils.checks.admin_only(),
which re-verifies the CALLER's Discord ID against config.settings.admin_ids
server-side — a user-supplied ID (e.g. the target of /admin addbalance) is
only ever used as a *target*, never trusted to grant the caller permission.
All admin actions are written to audit_logs and logs/admin.log.
"""
from __future__ import annotations

import discord
from discord import app_commands
from discord.ext import commands

from providers.base import ProviderError
from services.payments import confirm_payment
from utils import embeds
from utils.checks import admin_only
from utils.helpers import new_error_id
from utils.logger import admin_logger


class AdminCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @property
    def db(self):
        return self.bot.db

    @property
    def provider(self):
        return self.bot.provider

    admin_group = app_commands.Group(name="admin", description="Administrator commands.")

    async def _log(self, interaction: discord.Interaction, action: str, target: str = "", details: str = ""):
        await self.db.log_audit(interaction.user.id, action, target, details)
        admin_logger.info("admin=%s action=%s target=%s details=%s", interaction.user.id, action, target, details)

    @admin_group.command(name="addbalance", description="Add credits to a user's balance.")
    @admin_only()
    async def addbalance(self, interaction: discord.Interaction, user: discord.User, amount: float):
        await self.db.get_or_create_user(user.id)
        new_balance = await self.db.adjust_balance(user.id, amount, "admin_credit", f"By admin {interaction.user.id}")
        await self._log(interaction, "addbalance", target=str(user.id), details=f"+{amount}")
        await interaction.response.send_message(
            embed=embeds.success_embed("Balance updated", f"{user.mention} now has {new_balance:.2f} credits."),
            ephemeral=True,
        )

    @admin_group.command(name="removebalance", description="Remove credits from a user's balance.")
    @admin_only()
    async def removebalance(self, interaction: discord.Interaction, user: discord.User, amount: float):
        try:
            new_balance = await self.db.adjust_balance(user.id, -amount, "admin_debit", f"By admin {interaction.user.id}")
        except ValueError:
            await interaction.response.send_message(embed=embeds.error_embed("User balance would go negative."), ephemeral=True)
            return
        await self._log(interaction, "removebalance", target=str(user.id), details=f"-{amount}")
        await interaction.response.send_message(
            embed=embeds.success_embed("Balance updated", f"{user.mention} now has {new_balance:.2f} credits."),
            ephemeral=True,
        )

    @admin_group.command(name="deploy", description="Force-deploy a VPS for a user, bypassing balance checks.")
    @admin_only()
    async def force_deploy(self, interaction: discord.Interaction, user: discord.User, plan_name: str, hostname: str, os_image: str):
        plans = {p["name"].lower(): p for p in await self.db.list_plans()}
        plan = plans.get(plan_name.lower())
        if not plan:
            await interaction.response.send_message(embed=embeds.error_embed("Unknown plan."), ephemeral=True)
            return
        from utils.helpers import validate_hostname

        valid, err = validate_hostname(hostname)
        if not valid:
            await interaction.response.send_message(embed=embeds.error_embed("Invalid hostname", err), ephemeral=True)
            return
        await self.db.get_or_create_user(user.id)
        await interaction.response.defer(ephemeral=True)
        from services.deployment import DeploymentRequest

        request = DeploymentRequest(owner_id=user.id, hostname=hostname, os_image=os_image, plan_row=dict(plan))
        # Refund the plan cost immediately after charge since this is a free admin grant.
        result = await self.bot.deployment_queue.submit(request)
        if result["ok"]:
            await self.db.adjust_balance(user.id, plan["price"], "admin_grant_refund", "Admin force-deploy — cost waived")
        await self._log(interaction, "force_deploy", target=str(user.id), details=str(result.get("vps_id")))
        embed = embeds.success_embed("Deployed", f"VPS #{result['vps_id']} created for {user.mention}.") if result["ok"] \
            else embeds.error_embed("Deployment failed", result["error"], error_id=result.get("error_id"))
        await interaction.followup.send(embed=embed, ephemeral=True)

    @admin_group.command(name="delete", description="Force-delete any VPS.")
    @admin_only()
    async def force_delete(self, interaction: discord.Interaction, vps_id: int):
        vps = await self.db.get_vps(vps_id)
        if not vps:
            await interaction.response.send_message(embed=embeds.error_embed("VPS not found."), ephemeral=True)
            return
        await interaction.response.defer(ephemeral=True)
        try:
            await self.provider.delete_vps(vps["container_name"])
        except ProviderError as exc:
            eid = new_error_id()
            admin_logger.error("force_delete failed [%s]: %s", eid, exc)
        await self.db.release_ports(vps_id)
        await self.db.update_vps(vps_id, status="deleted")
        await self._log(interaction, "force_delete", target=f"vps:{vps_id}")
        await interaction.followup.send(embed=embeds.success_embed("Deleted", f"VPS #{vps_id} deleted."), ephemeral=True)

    @admin_group.command(name="suspend", description="Suspend a user's account (blocks new deployments).")
    @admin_only()
    async def suspend(self, interaction: discord.Interaction, user: discord.User):
        await self.db.get_or_create_user(user.id)
        await self.db._conn.execute("UPDATE users SET is_suspended = 1 WHERE discord_id = ?", (user.id,))
        await self.db._conn.commit()
        await self._log(interaction, "suspend_user", target=str(user.id))
        await interaction.response.send_message(embed=embeds.success_embed("Suspended", f"{user.mention} suspended."), ephemeral=True)

    @admin_group.command(name="unsuspend", description="Unsuspend a user's account.")
    @admin_only()
    async def unsuspend(self, interaction: discord.Interaction, user: discord.User):
        await self.db._conn.execute("UPDATE users SET is_suspended = 0 WHERE discord_id = ?", (user.id,))
        await self.db._conn.commit()
        await self._log(interaction, "unsuspend_user", target=str(user.id))
        await interaction.response.send_message(embed=embeds.success_embed("Unsuspended", f"{user.mention} unsuspended."), ephemeral=True)

    @admin_group.command(name="users", description="List users (paginated summary).")
    @admin_only()
    async def list_users(self, interaction: discord.Interaction, page: int = 1):
        cur = await self.db._conn.execute(
            "SELECT * FROM users ORDER BY discord_id LIMIT 10 OFFSET ?", ((page - 1) * 10,)
        )
        rows = await cur.fetchall()
        if not rows:
            await interaction.response.send_message(embed=embeds.info_embed("No more users."), ephemeral=True)
            return
        lines = [f"<@{r['discord_id']}> — {r['balance']:.2f} cr — {'SUSPENDED' if r['is_suspended'] else 'active'}" for r in rows]
        await interaction.response.send_message(embed=embeds.info_embed(f"Users (page {page})", "\n".join(lines)), ephemeral=True)

    @admin_group.command(name="vps", description="List all VPS on the platform, optionally filtered by status.")
    @admin_only()
    async def list_vps(self, interaction: discord.Interaction, status: str | None = None):
        rows = await self.db.list_all_vps(status)
        if not rows:
            await interaction.response.send_message(embed=embeds.info_embed("No VPS found."), ephemeral=True)
            return
        lines = [f"#{r['id']} {r['hostname']} — <@{r['owner_id']}> — {r['status']}" for r in rows[:20]]
        await interaction.response.send_message(embed=embeds.info_embed(f"VPS ({len(rows)} total)", "\n".join(lines)), ephemeral=True)

    @admin_group.command(name="stats", description="Platform-wide statistics dashboard.")
    @admin_only()
    async def stats(self, interaction: discord.Interaction):
        cur = await self.db._conn.execute("SELECT COUNT(*) c FROM users")
        total_users = (await cur.fetchone())["c"]
        active = len(await self.db.list_all_vps("running"))
        suspended = len(await self.db.list_all_vps("suspended"))
        cur = await self.db._conn.execute(
            "SELECT COALESCE(SUM(amount),0) c FROM transactions WHERE type IN ('purchase','renewal','topup','admin_credit') "
            "AND date(created_at) = date('now')"
        )
        today_revenue = (await cur.fetchone())["c"]
        capacity = await self.provider.host_capacity()
        e = embeds.info_embed("📊 Admin Dashboard")
        e.add_field(name="Total Users", value=str(total_users), inline=True)
        e.add_field(name="Active VPS", value=str(active), inline=True)
        e.add_field(name="Suspended VPS", value=str(suspended), inline=True)
        e.add_field(name="Today's Activity", value=f"{today_revenue:.2f} credits", inline=True)
        e.add_field(name="CPU Available", value=f"{capacity['cpu_available']:.1f} / {capacity['cpu_total']}", inline=True)
        e.add_field(name="RAM Available", value=f"{capacity['ram_available_mb']:.0f} / {capacity['ram_total_mb']:.0f} MB", inline=True)
        await interaction.response.send_message(embed=e, ephemeral=True)

    @admin_group.command(name="broadcast", description="DM all known users an announcement.")
    @admin_only()
    async def broadcast(self, interaction: discord.Interaction, message: str):
        await interaction.response.defer(ephemeral=True)
        cur = await self.db._conn.execute("SELECT discord_id FROM users")
        rows = await cur.fetchall()
        sent = 0
        for r in rows:
            try:
                u = await self.bot.fetch_user(r["discord_id"])
                await u.send(embed=embeds.info_embed("📢 Announcement", message))
                sent += 1
            except discord.Forbidden:
                continue
        await self._log(interaction, "broadcast", details=message[:200])
        await interaction.followup.send(embed=embeds.success_embed("Broadcast sent", f"Delivered to {sent}/{len(rows)} users."), ephemeral=True)

    @admin_group.command(name="maintenance", description="Toggle maintenance mode (blocks new deployments).")
    @admin_only()
    async def maintenance(self, interaction: discord.Interaction, enabled: bool):
        await self.db.set_setting("maintenance_mode", "1" if enabled else "0")
        await self._log(interaction, "maintenance", details=str(enabled))
        await interaction.response.send_message(
            embed=embeds.success_embed("Maintenance mode", f"Set to {'ON' if enabled else 'OFF'}."), ephemeral=True
        )

    @admin_group.command(name="setplan", description="Create or update a plan.")
    @admin_only()
    async def setplan(self, interaction: discord.Interaction, name: str, cpu: int, ram_mb: int, disk_gb: int, price: float, duration_days: int = 30):
        await self.db._conn.execute(
            """INSERT INTO plans (name, cpu, ram_mb, disk_gb, price, duration_days) VALUES (?, ?, ?, ?, ?, ?)
               ON CONFLICT(name) DO UPDATE SET cpu=excluded.cpu, ram_mb=excluded.ram_mb,
               disk_gb=excluded.disk_gb, price=excluded.price, duration_days=excluded.duration_days""",
            (name, cpu, ram_mb, disk_gb, price, duration_days),
        )
        await self.db._conn.commit()
        await self._log(interaction, "setplan", target=name)
        await interaction.response.send_message(embed=embeds.success_embed("Plan saved", f"`{name}` updated."), ephemeral=True)

    @admin_group.command(name="setlimit", description="Set a user's max VPS limit.")
    @admin_only()
    async def setlimit(self, interaction: discord.Interaction, user: discord.User, limit: int):
        await self.db.get_or_create_user(user.id)
        await self.db._conn.execute("UPDATE users SET vps_limit = ? WHERE discord_id = ?", (limit, user.id))
        await self.db._conn.commit()
        await self._log(interaction, "setlimit", target=str(user.id), details=str(limit))
        await interaction.response.send_message(embed=embeds.success_embed("Limit updated", f"{user.mention} limit set to {limit}."), ephemeral=True)

    @admin_group.command(name="backup", description="Trigger a settings/database backup snapshot.")
    @admin_only()
    async def backup(self, interaction: discord.Interaction):
        import shutil
        from config import DATA_DIR
        from utils.helpers import now_utc

        src = DATA_DIR / "bot.db"
        dst = DATA_DIR / f"bot_backup_{now_utc().strftime('%Y%m%d_%H%M%S')}.db"
        try:
            shutil.copyfile(src, dst)
        except OSError as exc:
            await interaction.response.send_message(embed=embeds.error_embed("Backup failed", str(exc)), ephemeral=True)
            return
        await self._log(interaction, "backup", details=str(dst.name))
        await interaction.response.send_message(embed=embeds.success_embed("Backup created", f"`{dst.name}`"), ephemeral=True)

    @admin_group.command(name="confirm-payment", description="Confirm a pending manual payment.")
    @admin_only()
    async def confirm_payment_cmd(self, interaction: discord.Interaction, payment_id: str):
        ok, message = await confirm_payment(self.db, payment_id, interaction.user.id)
        embed = embeds.success_embed("Confirmed", message) if ok else embeds.error_embed("Failed", message)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @admin_group.error
    async def admin_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        if isinstance(error, app_commands.CheckFailure):
            from utils.logger import security_logger

            security_logger.warning("Unauthorized admin attempt by %s: %s", interaction.user.id, error)
            if interaction.response.is_done():
                await interaction.followup.send(embed=embeds.error_embed("Not authorized."), ephemeral=True)
            else:
                await interaction.response.send_message(embed=embeds.error_embed("Not authorized."), ephemeral=True)
            return
        raise error


async def setup(bot: commands.Bot):
    cog = AdminCog(bot)
    await bot.add_cog(cog)
    bot.tree.add_command(cog.admin_group)
