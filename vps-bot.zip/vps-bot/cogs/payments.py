"""
cogs/payments.py
/buy — quick-purchase entry point. Kept as a thin wrapper around the same
guided flow as /deploy so there's a single source of truth for the
deployment steps (resource checks, balance checks, rollback-safe queue).
"""
from __future__ import annotations

import discord
from discord import app_commands
from discord.ext import commands

from utils import embeds


class PaymentsCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(name="buy", description="Buy a new VPS (same as /deploy).")
    async def buy(self, interaction: discord.Interaction):
        user_cog = self.bot.get_cog("UserCog")
        if not user_cog:
            await interaction.response.send_message(embed=embeds.error_embed("Deployment system unavailable."), ephemeral=True)
            return
        await user_cog.deploy.callback(user_cog, interaction)


async def setup(bot: commands.Bot):
    await bot.add_cog(PaymentsCog(bot))
