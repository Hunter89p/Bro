"""
cogs/vps.py
/vps — list-and-manage view with buttons (start/stop/restart/reinstall/
console/ssh/info/resources/backup/delete/rename/change password), plus the
direct slash subcommands for scripted/quick use. Dangerous actions
(delete, reinstall) require an explicit confirmation step.
"""
from __future__ import annotations

import discord
from discord import app_commands
from discord.ext import commands

from providers.base import ProviderError, VPSSpec
from services.security import decrypt_secret, encrypt_secret
from utils import embeds
from utils.helpers import generate_password, new_error_id
from utils.logger import bot_logger


class ConfirmView(discord.ui.View):
    def __init__(self, owner_id: int, timeout: float = 30):
        super().__init__(timeout=timeout)
        self.owner_id = owner_id
        self.confirmed: bool | None = None

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message("This confirmation isn't for you.", ephemeral=True)
            return False
        return True

    @discord.ui.button(label="Confirm", style=discord.ButtonStyle.danger)
    async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.confirmed = True
        for c in self.children:
            c.disabled = True
        await interaction.response.edit_message(view=self)
        self.stop()

    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary)
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.confirmed = False
        for c in self.children:
            c.disabled = True
        await interaction.response.edit_message(view=self)
        self.stop()


class VPSManageView(discord.ui.View):
    """One row of action buttons attached to a specific VPS."""

    def __init__(self, cog: "VPSCog", vps_id: int, owner_id: int, timeout: float = 180):
        super().__init__(timeout=timeout)
        self.cog = cog
        self.vps_id = vps_id
        self.owner_id = owner_id

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message("This isn't your VPS.", ephemeral=True)
            return False
        return True

    @discord.ui.button(label="Start", style=discord.ButtonStyle.success, row=0)
    async def start_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.cog._do_action(interaction, self.vps_id, "start")

    @discord.ui.button(label="Stop", style=discord.ButtonStyle.secondary, row=0)
    async def stop_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.cog._do_action(interaction, self.vps_id, "stop")

    @discord.ui.button(label="Restart", style=discord.ButtonStyle.primary, row=0)
    async def restart_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.cog._do_action(interaction, self.vps_id, "restart")

    @discord.ui.button(label="Info", style=discord.ButtonStyle.secondary, row=0)
    async def info_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        vps = await self.cog.db.get_vps(self.vps_id)
        await interaction.response.send_message(embed=embeds.vps_info_embed(dict(vps)), ephemeral=True)

    @discord.ui.button(label="Resources", style=discord.ButtonStyle.secondary, row=0)
    async def resources_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        vps = await self.cog.db.get_vps(self.vps_id)
        usage = await self.cog.provider.get_resources(vps["container_name"])
        if not usage:
            await interaction.response.send_message(
                embed=embeds.warning_embed("No live data", "VPS may not be running."), ephemeral=True
            )
            return
        e = embeds.info_embed(f"📊 Resource usage — {vps['hostname']}")
        e.add_field(name="CPU", value=f"{usage.cpu_percent}%", inline=True)
        e.add_field(name="RAM", value=f"{usage.ram_used_mb:.0f} / {usage.ram_limit_mb:.0f} MB", inline=True)
        await interaction.response.send_message(embed=e, ephemeral=True)

    @discord.ui.button(label="SSH", style=discord.ButtonStyle.primary, row=1)
    async def ssh_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        vps = await self.cog.db.get_vps(self.vps_id)
        if not vps["ssh_password_enc"]:
            await interaction.response.send_message(embed=embeds.error_embed("No credentials on file."), ephemeral=True)
            return
        password = decrypt_secret(vps["ssh_password_enc"])
        e = embeds.info_embed("🔐 SSH Details")
        e.add_field(name="Host", value=vps["ipv4"] or "pending", inline=True)
        e.add_field(name="Port", value=str(vps["ssh_port"]), inline=True)
        e.add_field(name="Username", value=vps["ssh_username"], inline=True)
        e.add_field(name="Password", value=f"||{password}||", inline=False)
        await interaction.response.send_message(embed=e, ephemeral=True)

    @discord.ui.button(label="Change Password", style=discord.ButtonStyle.primary, row=1)
    async def change_pw_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        vps = await self.cog.db.get_vps(self.vps_id)
        await interaction.response.defer(ephemeral=True)
        new_password = generate_password()
        try:
            await self.cog.provider.reset_password(vps["container_name"], vps["ssh_username"], new_password)
        except ProviderError as exc:
            eid = new_error_id()
            bot_logger.error("change_pw [%s]: %s", eid, exc)
            await interaction.followup.send(embed=embeds.error_embed("Failed", error_id=eid), ephemeral=True)
            return
        await self.cog.db.update_vps(self.vps_id, ssh_password_enc=encrypt_secret(new_password))
        e = embeds.success_embed("Password changed")
        e.add_field(name="New password", value=f"||{new_password}||")
        await interaction.followup.send(embed=e, ephemeral=True)

    @discord.ui.button(label="Rename", style=discord.ButtonStyle.secondary, row=1)
    async def rename_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(RenameModal(self.cog, self.vps_id))

    @discord.ui.button(label="Backup", style=discord.ButtonStyle.secondary, row=1)
    async def backup_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(
            embed=embeds.info_embed(
                "Backup queued",
                "Backups aren't implemented for the Docker provider in this build — "
                "wire up a volume-snapshot job in services/ to enable this for real.",
            ),
            ephemeral=True,
        )

    @discord.ui.button(label="Reinstall", style=discord.ButtonStyle.danger, row=2)
    async def reinstall_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        confirm = ConfirmView(self.owner_id)
        await interaction.response.send_message(
            embed=embeds.warning_embed("Confirm reinstall", "This wipes all data on the VPS. Continue?"),
            view=confirm,
            ephemeral=True,
        )
        await confirm.wait()
        if not confirm.confirmed:
            return
        await self.cog._do_reinstall(interaction, self.vps_id)

    @discord.ui.button(label="Delete", style=discord.ButtonStyle.danger, row=2)
    async def delete_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        confirm = ConfirmView(self.owner_id)
        await interaction.response.send_message(
            embed=embeds.warning_embed("Confirm delete", "This permanently deletes the VPS. Continue?"),
            view=confirm,
            ephemeral=True,
        )
        await confirm.wait()
        if not confirm.confirmed:
            return
        await self.cog._do_action(interaction, self.vps_id, "delete", already_responded=True)


class RenameModal(discord.ui.Modal, title="Rename VPS"):
    hostname = discord.ui.TextInput(label="New hostname", max_length=63)

    def __init__(self, cog: "VPSCog", vps_id: int):
        super().__init__()
        self.cog = cog
        self.vps_id = vps_id

    async def on_submit(self, interaction: discord.Interaction):
        from utils.helpers import validate_hostname

        valid, err = validate_hostname(str(self.hostname))
        if not valid:
            await interaction.response.send_message(embed=embeds.error_embed("Invalid hostname", err), ephemeral=True)
            return
        await self.cog.db.update_vps(self.vps_id, hostname=str(self.hostname))
        await interaction.response.send_message(
            embed=embeds.success_embed("Renamed", f"New hostname: `{self.hostname}`"), ephemeral=True
        )


class VPSCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @property
    def db(self):
        return self.bot.db

    @property
    def provider(self):
        return self.bot.provider

    async def _owns_or_admin(self, interaction: discord.Interaction, vps) -> bool:
        if not vps or vps["status"] == "deleted":
            await interaction.response.send_message(embed=embeds.error_embed("VPS not found."), ephemeral=True)
            return False
        if vps["owner_id"] != interaction.user.id and interaction.user.id not in self.bot.settings.admin_ids:
            await interaction.response.send_message(embed=embeds.error_embed("Not your VPS."), ephemeral=True)
            return False
        return True

    async def _do_action(self, interaction: discord.Interaction, vps_id: int, action: str, already_responded=False):
        vps = await self.db.get_vps(vps_id)
        if not vps:
            msg = embeds.error_embed("VPS not found.")
            if already_responded:
                await interaction.followup.send(embed=msg, ephemeral=True)
            else:
                await interaction.response.send_message(embed=msg, ephemeral=True)
            return
        if not already_responded:
            await interaction.response.defer(ephemeral=True)
        try:
            if action == "start":
                await self.provider.start_vps(vps["container_name"])
                await self.db.update_vps(vps_id, status="running")
            elif action == "stop":
                await self.provider.stop_vps(vps["container_name"])
                await self.db.update_vps(vps_id, status="stopped")
            elif action == "restart":
                await self.provider.restart_vps(vps["container_name"])
                await self.db.update_vps(vps_id, status="running")
            elif action == "delete":
                await self.provider.delete_vps(vps["container_name"])
                await self.db.release_ports(vps_id)
                await self.db.update_vps(vps_id, status="deleted")
            await self.db.log_audit(interaction.user.id, f"vps_{action}", target=f"vps:{vps_id}")
            await interaction.followup.send(embed=embeds.success_embed(f"VPS {action} succeeded."), ephemeral=True)
        except ProviderError as exc:
            eid = new_error_id()
            bot_logger.error("vps action %s failed [%s]: %s", action, eid, exc)
            await interaction.followup.send(embed=embeds.error_embed(f"{action.title()} failed", error_id=eid), ephemeral=True)

    async def _do_reinstall(self, interaction: discord.Interaction, vps_id: int):
        vps = await self.db.get_vps(vps_id)
        await interaction.followup.send(embed=embeds.info_embed("Reinstalling...", "This may take a moment."), ephemeral=True)
        new_password = generate_password()
        spec = VPSSpec(
            container_name=vps["container_name"],
            hostname=vps["hostname"],
            os_image=vps["os"],
            cpu=vps["cpu"],
            ram_mb=vps["ram_mb"],
            disk_gb=vps["disk_gb"],
            ssh_port=vps["ssh_port"],
            ssh_username=vps["ssh_username"] or "root",
            ssh_password=new_password,
        )
        try:
            info = await self.provider.reinstall_vps(vps["container_name"], spec)
            await self.db.update_vps(
                vps_id,
                status="running",
                ipv4=info.get("ipv4"),
                ipv6=info.get("ipv6"),
                ssh_password_enc=encrypt_secret(new_password),
            )
            await self.db.log_audit(interaction.user.id, "vps_reinstall", target=f"vps:{vps_id}")
            e = embeds.success_embed("Reinstalled", f"`{vps['hostname']}` reinstalled with a fresh image.")
            e.add_field(name="New password", value=f"||{new_password}||")
            await interaction.followup.send(embed=e, ephemeral=True)
        except ProviderError as exc:
            eid = new_error_id()
            bot_logger.error("reinstall failed [%s]: %s", eid, exc)
            await interaction.followup.send(embed=embeds.error_embed("Reinstall failed", error_id=eid), ephemeral=True)

    # ---------------- Slash commands ----------------

    @app_commands.command(name="vps", description="List and manage your VPS instances.")
    async def vps_list(self, interaction: discord.Interaction):
        rows = await self.db.list_user_vps(interaction.user.id)
        if not rows:
            await interaction.response.send_message(embed=embeds.info_embed("No VPS instances", "Use `/deploy` to create one."), ephemeral=True)
            return
        # Show the first VPS with full controls; list the rest as a summary.
        first = dict(rows[0])
        embed = embeds.vps_info_embed(first)
        if len(rows) > 1:
            others = "\n".join(f"#{r['id']} — {r['hostname']} ({r['status']})" for r in rows[1:])
            embed.add_field(name="Other VPS", value=others, inline=False)
        view = VPSManageView(self, first["id"], interaction.user.id)
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)

    vps_group = app_commands.Group(name="vpsctl", description="Direct VPS lifecycle commands.")

    @vps_group.command(name="start", description="Start a VPS.")
    async def start(self, interaction: discord.Interaction, vps_id: int):
        vps = await self.db.get_vps(vps_id)
        if not await self._owns_or_admin(interaction, vps):
            return
        await self._do_action(interaction, vps_id, "start")

    @vps_group.command(name="stop", description="Stop a VPS.")
    async def stop(self, interaction: discord.Interaction, vps_id: int):
        vps = await self.db.get_vps(vps_id)
        if not await self._owns_or_admin(interaction, vps):
            return
        await self._do_action(interaction, vps_id, "stop")

    @vps_group.command(name="restart", description="Restart a VPS.")
    async def restart(self, interaction: discord.Interaction, vps_id: int):
        vps = await self.db.get_vps(vps_id)
        if not await self._owns_or_admin(interaction, vps):
            return
        await self._do_action(interaction, vps_id, "restart")

    @vps_group.command(name="delete", description="Permanently delete a VPS.")
    async def delete(self, interaction: discord.Interaction, vps_id: int):
        vps = await self.db.get_vps(vps_id)
        if not await self._owns_or_admin(interaction, vps):
            return
        confirm = ConfirmView(interaction.user.id)
        await interaction.response.send_message(
            embed=embeds.warning_embed("Confirm delete", f"Permanently delete `{vps['hostname']}`?"),
            view=confirm,
            ephemeral=True,
        )
        await confirm.wait()
        if confirm.confirmed:
            await self._do_action(interaction, vps_id, "delete", already_responded=True)

    @vps_group.command(name="reinstall", description="Wipe and reinstall a VPS.")
    async def reinstall(self, interaction: discord.Interaction, vps_id: int):
        vps = await self.db.get_vps(vps_id)
        if not await self._owns_or_admin(interaction, vps):
            return
        confirm = ConfirmView(interaction.user.id)
        await interaction.response.send_message(
            embed=embeds.warning_embed("Confirm reinstall", f"This wipes all data on `{vps['hostname']}`."),
            view=confirm,
            ephemeral=True,
        )
        await confirm.wait()
        if confirm.confirmed:
            await self._do_reinstall(interaction, vps_id)


async def setup(bot: commands.Bot):
    cog = VPSCog(bot)
    await bot.add_cog(cog)
    bot.tree.add_command(cog.vps_group)
