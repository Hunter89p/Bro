"""
cogs/billing.py
/buy, /renew, /upgrade, /billing, /addbalance — subscription purchase and
management, layered on services/billing.py and services/payments.py.
"""
from __future__ import annotations

import discord
from discord import app_commands
from discord.ext import commands

from services.payments import get_payment_provider
from utils import embeds


class BillingCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @property
    def db(self):
        return self.bot.db

    @property
    def billing_service(self):
        return self.bot.billing_service

    @app_commands.command(name="addbalance", description="Add credits to your account via the configured payment provider.")
    @app_commands.describe(amount="Amount of credits to purchase")
    async def addbalance(self, interaction: discord.Interaction, amount: float):
        if amount <= 0:
            await interaction.response.send_message(embed=embeds.error_embed("Amount must be positive."), ephemeral=True)
            return
        await self.db.get_or_create_user(interaction.user.id)
        provider = get_payment_provider()
        result = await provider.initiate(self.db, interaction.user.id, amount)
        await interaction.response.send_message(
            embed=embeds.info_embed("💳 Payment initiated", result["instructions"]), ephemeral=True
        )

    @app_commands.command(name="renew", description="Renew a VPS subscription.")
    @app_commands.describe(vps_id="The VPS ID to renew")
    async def renew(self, interaction: discord.Interaction, vps_id: int):
        await interaction.response.defer(ephemeral=True)
        ok, message = await self.billing_service.renew(vps_id, interaction.user.id)
        embed = embeds.success_embed("Renewed", message) if ok else embeds.error_embed("Renewal failed", message)
        await interaction.followup.send(embed=embed, ephemeral=True)

    @app_commands.command(name="upgrade", description="Upgrade a VPS to a higher plan.")
    @app_commands.describe(vps_id="The VPS ID", plan_name="The plan to upgrade to")
    async def upgrade(self, interaction: discord.Interaction, vps_id: int, plan_name: str):
        vps = await self.db.get_vps(vps_id)
        if not vps or vps["owner_id"] != interaction.user.id:
            await interaction.response.send_message(embed=embeds.error_embed("VPS not found."), ephemeral=True)
            return
        plans = {p["name"].lower(): p for p in await self.db.list_plans()}
        target = plans.get(plan_name.lower())
        if not target:
            await interaction.response.send_message(embed=embeds.error_embed("Unknown plan."), ephemeral=True)
            return
        if target["cpu"] < vps["cpu"] or target["ram_mb"] < vps["ram_mb"]:
            await interaction.response.send_message(
                embed=embeds.error_embed("Not an upgrade", "Target plan must be equal or higher spec."), ephemeral=True
            )
            return
        price_diff = target["price"] - next(
            p["price"] for p in await self.db.list_plans() if p["id"] == vps["plan_id"]
        )
        if price_diff < 0:
            price_diff = 0
        await interaction.response.defer(ephemeral=True)
        try:
            await self.db.adjust_balance(interaction.user.id, -price_diff, "upgrade", f"Upgrade VPS #{vps_id}")
        except ValueError:
            await interaction.followup.send(embed=embeds.error_embed("Insufficient balance for upgrade."), ephemeral=True)
            return
        await self.db.update_vps(
            vps_id, plan_id=target["id"], plan_name=target["name"], cpu=target["cpu"],
            ram_mb=target["ram_mb"], disk_gb=target["disk_gb"],
        )
        await self.db.log_audit(interaction.user.id, "upgrade", target=f"vps:{vps_id}", details=target["name"])
        await interaction.followup.send(
            embed=embeds.success_embed(
                "Upgraded", f"`{vps['hostname']}` is now on the **{target['name']}** plan. "
                "Restart the VPS to apply new resource limits."
            ),
            ephemeral=True,
        )

    @app_commands.command(name="billing", description="Show your billing summary.")
    async def billing(self, interaction: discord.Interaction):
        user = await self.db.get_or_create_user(interaction.user.id)
        vps_list = await self.db.list_user_vps(interaction.user.id)
        e = embeds.info_embed("🧾 Billing Summary")
        e.add_field(name="Balance", value=f"{user['balance']:.2f} credits", inline=True)
        e.add_field(name="Active VPS", value=str(len(vps_list)), inline=True)
        for v in vps_list:
            e.add_field(name=f"#{v['id']} {v['hostname']}", value=f"{v['plan_name']} — expires {v['expires_at'][:10]}", inline=False)
        await interaction.response.send_message(embed=e, ephemeral=True)


async def setup(bot: commands.Bot):
    await bot.add_cog(BillingCog(bot))
