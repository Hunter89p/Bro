"""
config.py
Centralized configuration loader. Everything sensitive is read from
environment variables (via .env) — nothing here is hardcoded.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import List

from dotenv import load_dotenv

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
LOG_DIR = BASE_DIR / "logs"
DATA_DIR.mkdir(exist_ok=True)
LOG_DIR.mkdir(exist_ok=True)


def _get_bool(name: str, default: bool = False) -> bool:
    val = os.getenv(name)
    if val is None:
        return default
    return val.strip().lower() in {"1", "true", "yes", "on"}


def _get_int(name: str, default: int) -> int:
    val = os.getenv(name)
    if val is None or val.strip() == "":
        return default
    try:
        return int(val)
    except ValueError:
        return default


def _get_id_list(name: str) -> List[int]:
    raw = os.getenv(name, "")
    out: List[int] = []
    for part in raw.split(","):
        part = part.strip()
        if part.isdigit():
            out.append(int(part))
    return out


@dataclass(frozen=True)
class Settings:
    # --- Discord ---
    discord_token: str = field(default_factory=lambda: os.getenv("DISCORD_TOKEN", ""))
    admin_ids: List[int] = field(default_factory=lambda: _get_id_list("ADMIN_IDS"))
    guild_id: int | None = field(
        default_factory=lambda: (int(os.getenv("GUILD_ID")) if os.getenv("GUILD_ID") else None)
    )

    # --- Database ---
    database_url: str = field(
        default_factory=lambda: os.getenv("DATABASE_URL", f"sqlite:///{DATA_DIR / 'bot.db'}")
    )

    # --- Provider ---
    provider_type: str = field(default_factory=lambda: os.getenv("PROVIDER_TYPE", "docker").lower())
    docker_host: str = field(default_factory=lambda: os.getenv("DOCKER_HOST", "unix:///var/run/docker.sock"))
    lxc_host: str = field(default_factory=lambda: os.getenv("LXC_HOST", ""))
    proxmox_host: str = field(default_factory=lambda: os.getenv("PROXMOX_HOST", ""))
    proxmox_token: str = field(default_factory=lambda: os.getenv("PROXMOX_TOKEN", ""))

    # --- Networking ---
    docker_network_name: str = field(default_factory=lambda: os.getenv("DOCKER_NETWORK_NAME", "vpsbot_net"))
    docker_network_subnet: str = field(default_factory=lambda: os.getenv("DOCKER_NETWORK_SUBNET", "10.77.0.0/16"))
    port_range_start: int = field(default_factory=lambda: _get_int("PORT_RANGE_START", 20000))
    port_range_end: int = field(default_factory=lambda: _get_int("PORT_RANGE_END", 29999))

    # --- Limits ---
    default_vps_limit: int = field(default_factory=lambda: _get_int("DEFAULT_VPS_LIMIT", 2))
    default_grace_period_hours: int = field(default_factory=lambda: _get_int("DEFAULT_GRACE_PERIOD", 72))
    max_deployments_per_hour: int = field(default_factory=lambda: _get_int("MAX_DEPLOYMENTS_PER_HOUR", 3))
    max_concurrent_deployments: int = field(default_factory=lambda: _get_int("MAX_CONCURRENT_DEPLOYMENTS", 2))
    deployment_worker_count: int = field(default_factory=lambda: _get_int("DEPLOYMENT_WORKERS", 2))

    # --- Host resource ceiling (safety valve so the bot never over-allocates) ---
    host_max_cpu: int = field(default_factory=lambda: _get_int("HOST_MAX_CPU", 32))
    host_max_ram_mb: int = field(default_factory=lambda: _get_int("HOST_MAX_RAM_MB", 65536))
    host_max_disk_gb: int = field(default_factory=lambda: _get_int("HOST_MAX_DISK_GB", 2000))

    # --- Payments ---
    payment_provider: str = field(default_factory=lambda: os.getenv("PAYMENT_PROVIDER", "manual").lower())
    payment_secret: str = field(default_factory=lambda: os.getenv("PAYMENT_SECRET", ""))

    # --- Misc ---
    log_level: str = field(default_factory=lambda: os.getenv("LOG_LEVEL", "INFO"))
    command_prefix: str = field(default_factory=lambda: os.getenv("COMMAND_PREFIX", "!"))
    enable_prefix_commands: bool = field(default_factory=lambda: _get_bool("ENABLE_PREFIX_COMMANDS", False))

    def validate(self) -> list[str]:
        """Return a list of human-readable config problems (empty = OK)."""
        problems: list[str] = []
        if not self.discord_token:
            problems.append("DISCORD_TOKEN is not set.")
        if not self.admin_ids:
            problems.append("ADMIN_IDS is not set — no one will be able to use /admin commands.")
        if self.provider_type not in {"docker", "lxc", "lxd", "proxmox", "custom"}:
            problems.append(f"PROVIDER_TYPE '{self.provider_type}' is not recognized.")
        if self.provider_type == "proxmox" and not (self.proxmox_host and self.proxmox_token):
            problems.append("PROVIDER_TYPE=proxmox requires PROXMOX_HOST and PROXMOX_TOKEN.")
        if self.port_range_start >= self.port_range_end:
            problems.append("PORT_RANGE_START must be less than PORT_RANGE_END.")
        return problems


settings = Settings()
