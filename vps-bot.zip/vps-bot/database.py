"""
database.py
Async SQLite data layer (aiosqlite). Architected so swapping to PostgreSQL
later only means changing the connection layer — all queries here use
parameterized statements and are wrapped in explicit transactions where
multiple tables are touched together (balance deduction + VPS creation,
etc.), with rollback on failure.
"""
from __future__ import annotations

import json
from contextlib import asynccontextmanager
from typing import Any, AsyncIterator, Optional

import aiosqlite

from config import settings
from utils.helpers import now_utc, new_tx_id
from utils.logger import bot_logger, error_logger

SCHEMA = """
PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
    discord_id      INTEGER PRIMARY KEY,
    balance         REAL NOT NULL DEFAULT 0,
    vps_limit       INTEGER NOT NULL DEFAULT 2,
    is_suspended    INTEGER NOT NULL DEFAULT 0,
    invited_by      INTEGER,
    last_daily_at   TEXT,
    created_at      TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS plans (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    name            TEXT NOT NULL UNIQUE,
    cpu             INTEGER NOT NULL,
    ram_mb          INTEGER NOT NULL,
    disk_gb         INTEGER NOT NULL,
    price           REAL NOT NULL,
    duration_days   INTEGER NOT NULL DEFAULT 30,
    is_active       INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS vps (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_id        INTEGER NOT NULL REFERENCES users(discord_id),
    hostname        TEXT NOT NULL,
    container_name  TEXT NOT NULL UNIQUE,
    os              TEXT NOT NULL,
    plan_id         INTEGER NOT NULL REFERENCES plans(id),
    plan_name       TEXT NOT NULL,
    cpu             INTEGER NOT NULL,
    ram_mb          INTEGER NOT NULL,
    disk_gb         INTEGER NOT NULL,
    status          TEXT NOT NULL DEFAULT 'provisioning',
    provider        TEXT NOT NULL,
    ipv4            TEXT,
    ipv6            TEXT,
    ssh_port        INTEGER,
    ssh_username    TEXT,
    ssh_password_enc TEXT,
    created_at      TEXT NOT NULL,
    expires_at      TEXT NOT NULL,
    suspended_at    TEXT,
    warned_3d       INTEGER NOT NULL DEFAULT 0,
    warned_24h      INTEGER NOT NULL DEFAULT 0,
    warned_expired  INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS transactions (
    id              TEXT PRIMARY KEY,
    user_id         INTEGER NOT NULL REFERENCES users(discord_id),
    amount          REAL NOT NULL,
    type            TEXT NOT NULL,
    description     TEXT,
    created_at      TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS payments (
    id              TEXT PRIMARY KEY,
    user_id         INTEGER NOT NULL REFERENCES users(discord_id),
    amount          REAL NOT NULL,
    provider        TEXT NOT NULL,
    status          TEXT NOT NULL DEFAULT 'pending',
    external_ref    TEXT,
    created_at      TEXT NOT NULL,
    confirmed_at    TEXT
);

CREATE TABLE IF NOT EXISTS invites (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    inviter_id      INTEGER NOT NULL,
    invitee_id      INTEGER NOT NULL UNIQUE,
    rewarded        INTEGER NOT NULL DEFAULT 0,
    created_at      TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS deployments (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id         INTEGER NOT NULL,
    vps_id          INTEGER,
    status          TEXT NOT NULL,
    error_id        TEXT,
    error_message   TEXT,
    created_at      TEXT NOT NULL,
    finished_at     TEXT
);

CREATE TABLE IF NOT EXISTS audit_logs (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    actor_id        INTEGER NOT NULL,
    action          TEXT NOT NULL,
    target           TEXT,
    details         TEXT,
    created_at      TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS port_allocations (
    port            INTEGER PRIMARY KEY,
    vps_id          INTEGER NOT NULL REFERENCES vps(id),
    purpose         TEXT NOT NULL DEFAULT 'ssh',
    created_at      TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS settings (
    key             TEXT PRIMARY KEY,
    value           TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_vps_owner ON vps(owner_id);
CREATE INDEX IF NOT EXISTS idx_vps_status ON vps(status);
CREATE INDEX IF NOT EXISTS idx_vps_expires ON vps(expires_at);
CREATE INDEX IF NOT EXISTS idx_tx_user ON transactions(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_actor ON audit_logs(actor_id);
"""

DEFAULT_PLANS = [
    ("Basic", 1, 1024, 10, 5.0, 30),
    ("Pro", 2, 4096, 30, 15.0, 30),
    ("Ultra", 4, 8192, 60, 30.0, 30),
]

_DB_PATH = settings.database_url.replace("sqlite:///", "", 1)


class Database:
    def __init__(self, path: str = _DB_PATH) -> None:
        self.path = path
        self._conn: Optional[aiosqlite.Connection] = None

    async def connect(self) -> None:
        self._conn = await aiosqlite.connect(self.path)
        self._conn.row_factory = aiosqlite.Row
        await self._conn.executescript(SCHEMA)
        await self._seed_defaults()
        await self._conn.commit()
        bot_logger.info("Database connected at %s", self.path)

    async def close(self) -> None:
        if self._conn:
            await self._conn.close()

    async def _seed_defaults(self) -> None:
        cur = await self._conn.execute("SELECT COUNT(*) AS c FROM plans")
        row = await cur.fetchone()
        if row["c"] == 0:
            for name, cpu, ram, disk, price, duration in DEFAULT_PLANS:
                await self._conn.execute(
                    "INSERT INTO plans (name, cpu, ram_mb, disk_gb, price, duration_days) "
                    "VALUES (?, ?, ?, ?, ?, ?)",
                    (name, cpu, ram, disk, price, duration),
                )

    @asynccontextmanager
    async def transaction(self) -> AsyncIterator[aiosqlite.Connection]:
        """Explicit transaction with rollback on any exception."""
        assert self._conn is not None
        try:
            yield self._conn
            await self._conn.commit()
        except Exception:
            await self._conn.rollback()
            raise

    # ---------------- Users ----------------

    async def get_or_create_user(self, discord_id: int) -> aiosqlite.Row:
        cur = await self._conn.execute("SELECT * FROM users WHERE discord_id = ?", (discord_id,))
        row = await cur.fetchone()
        if row:
            return row
        await self._conn.execute(
            "INSERT INTO users (discord_id, balance, vps_limit, created_at) VALUES (?, 0, ?, ?)",
            (discord_id, settings.default_vps_limit, now_utc().isoformat()),
        )
        await self._conn.commit()
        cur = await self._conn.execute("SELECT * FROM users WHERE discord_id = ?", (discord_id,))
        return await cur.fetchone()

    async def adjust_balance(self, discord_id: int, delta: float, tx_type: str, description: str = "") -> float:
        """Atomically adjust a user's balance and log the transaction. Raises ValueError on insufficient funds."""
        async with self.transaction() as conn:
            cur = await conn.execute("SELECT balance FROM users WHERE discord_id = ?", (discord_id,))
            row = await cur.fetchone()
            if row is None:
                raise ValueError("User does not exist.")
            new_balance = row["balance"] + delta
            if new_balance < 0:
                raise ValueError("Insufficient balance.")
            await conn.execute(
                "UPDATE users SET balance = ? WHERE discord_id = ?", (new_balance, discord_id)
            )
            await conn.execute(
                "INSERT INTO transactions (id, user_id, amount, type, description, created_at) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (new_tx_id(), discord_id, delta, tx_type, description, now_utc().isoformat()),
            )
            return new_balance

    # ---------------- Plans ----------------

    async def list_plans(self, active_only: bool = True) -> list[aiosqlite.Row]:
        q = "SELECT * FROM plans" + (" WHERE is_active = 1" if active_only else "")
        cur = await self._conn.execute(q)
        return await cur.fetchall()

    async def get_plan(self, plan_id: int) -> Optional[aiosqlite.Row]:
        cur = await self._conn.execute("SELECT * FROM plans WHERE id = ?", (plan_id,))
        return await cur.fetchone()

    # ---------------- VPS ----------------

    async def count_user_vps(self, owner_id: int) -> int:
        cur = await self._conn.execute(
            "SELECT COUNT(*) AS c FROM vps WHERE owner_id = ? AND status != 'deleted'", (owner_id,)
        )
        row = await cur.fetchone()
        return row["c"]

    async def create_vps_record(self, conn: aiosqlite.Connection, data: dict) -> int:
        cur = await conn.execute(
            """INSERT INTO vps (owner_id, hostname, container_name, os, plan_id, plan_name,
               cpu, ram_mb, disk_gb, status, provider, created_at, expires_at)
               VALUES (:owner_id, :hostname, :container_name, :os, :plan_id, :plan_name,
               :cpu, :ram_mb, :disk_gb, :status, :provider, :created_at, :expires_at)""",
            data,
        )
        return cur.lastrowid

    async def update_vps(self, vps_id: int, **fields: Any) -> None:
        if not fields:
            return
        cols = ", ".join(f"{k} = ?" for k in fields)
        values = list(fields.values()) + [vps_id]
        await self._conn.execute(f"UPDATE vps SET {cols} WHERE id = ?", values)
        await self._conn.commit()

    async def get_vps(self, vps_id: int) -> Optional[aiosqlite.Row]:
        cur = await self._conn.execute("SELECT * FROM vps WHERE id = ?", (vps_id,))
        return await cur.fetchone()

    async def list_user_vps(self, owner_id: int) -> list[aiosqlite.Row]:
        cur = await self._conn.execute(
            "SELECT * FROM vps WHERE owner_id = ? AND status != 'deleted' ORDER BY id", (owner_id,)
        )
        return await cur.fetchall()

    async def list_all_vps(self, status: Optional[str] = None) -> list[aiosqlite.Row]:
        if status:
            cur = await self._conn.execute("SELECT * FROM vps WHERE status = ?", (status,))
        else:
            cur = await self._conn.execute("SELECT * FROM vps WHERE status != 'deleted'")
        return await cur.fetchall()

    async def list_expiring(self) -> list[aiosqlite.Row]:
        cur = await self._conn.execute(
            "SELECT * FROM vps WHERE status IN ('running','stopped','suspended')"
        )
        return await cur.fetchall()

    async def sum_active_resources(self) -> aiosqlite.Row:
        cur = await self._conn.execute(
            "SELECT COALESCE(SUM(cpu),0) AS cpu, COALESCE(SUM(ram_mb),0) AS ram_mb, "
            "COALESCE(SUM(disk_gb),0) AS disk_gb FROM vps WHERE status IN ('running','stopped','provisioning')"
        )
        return await cur.fetchone()

    # ---------------- Ports ----------------

    async def allocate_port(self, conn: aiosqlite.Connection, vps_id: int, purpose: str = "ssh") -> int:
        cur = await conn.execute("SELECT port FROM port_allocations")
        used = {r["port"] for r in await cur.fetchall()}
        for port in range(settings.port_range_start, settings.port_range_end + 1):
            if port not in used:
                await conn.execute(
                    "INSERT INTO port_allocations (port, vps_id, purpose, created_at) VALUES (?, ?, ?, ?)",
                    (port, vps_id, purpose, now_utc().isoformat()),
                )
                return port
        raise RuntimeError("No available ports in configured range.")

    async def release_ports(self, vps_id: int) -> None:
        await self._conn.execute("DELETE FROM port_allocations WHERE vps_id = ?", (vps_id,))
        await self._conn.commit()

    # ---------------- Deployments / Audit ----------------

    async def log_deployment(self, user_id: int, status: str, vps_id: Optional[int] = None,
                              error_id: Optional[str] = None, error_message: Optional[str] = None) -> None:
        await self._conn.execute(
            "INSERT INTO deployments (user_id, vps_id, status, error_id, error_message, created_at, finished_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (user_id, vps_id, status, error_id, error_message, now_utc().isoformat(),
             now_utc().isoformat() if status in ("success", "failed") else None),
        )
        await self._conn.commit()

    async def log_audit(self, actor_id: int, action: str, target: str = "", details: str = "") -> None:
        await self._conn.execute(
            "INSERT INTO audit_logs (actor_id, action, target, details, created_at) VALUES (?, ?, ?, ?, ?)",
            (actor_id, action, target, details, now_utc().isoformat()),
        )
        await self._conn.commit()

    # ---------------- Invites ----------------

    async def record_invite(self, inviter_id: int, invitee_id: int) -> bool:
        try:
            await self._conn.execute(
                "INSERT INTO invites (inviter_id, invitee_id, created_at) VALUES (?, ?, ?)",
                (inviter_id, invitee_id, now_utc().isoformat()),
            )
            await self._conn.commit()
            return True
        except aiosqlite.IntegrityError:
            return False  # duplicate invite detection

    # ---------------- Settings ----------------

    async def get_setting(self, key: str, default: str | None = None) -> str | None:
        cur = await self._conn.execute("SELECT value FROM settings WHERE key = ?", (key,))
        row = await cur.fetchone()
        return row["value"] if row else default

    async def set_setting(self, key: str, value: str) -> None:
        await self._conn.execute(
            "INSERT INTO settings (key, value) VALUES (?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
            (key, value),
        )
        await self._conn.commit()


db = Database()
