"""
providers/base.py
Common interface every virtualization backend must implement. The rest of
the bot (services/deployment.py, cogs) only ever talks to this interface,
never to a concrete provider — so swapping Docker for LXD/Proxmox later
means writing one new class, not touching the bot.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Optional


class ProviderError(Exception):
    """Raised for any provider-level failure. Never leaks raw stack traces to Discord."""


@dataclass
class VPSSpec:
    container_name: str
    hostname: str
    os_image: str
    cpu: int
    ram_mb: int
    disk_gb: int
    ssh_port: int
    ssh_username: str
    ssh_password: str


@dataclass
class VPSResourceUsage:
    cpu_percent: float
    ram_used_mb: float
    ram_limit_mb: float
    disk_used_gb: float
    disk_limit_gb: float
    uptime_seconds: int


class VPSProvider(ABC):
    """Abstract base class for all VPS backends."""

    name: str = "base"

    @abstractmethod
    async def create_vps(self, spec: VPSSpec) -> dict:
        """Provision a new instance. Returns dict with at least {ipv4, ipv6}."""

    @abstractmethod
    async def start_vps(self, container_name: str) -> None:
        ...

    @abstractmethod
    async def stop_vps(self, container_name: str) -> None:
        ...

    @abstractmethod
    async def restart_vps(self, container_name: str) -> None:
        ...

    @abstractmethod
    async def delete_vps(self, container_name: str) -> None:
        ...

    @abstractmethod
    async def reinstall_vps(self, container_name: str, spec: VPSSpec) -> dict:
        """Destroy and recreate the instance with the same spec. Returns new connection info."""

    @abstractmethod
    async def get_status(self, container_name: str) -> str:
        """Returns one of: running, stopped, suspended, missing, error."""

    @abstractmethod
    async def get_resources(self, container_name: str) -> Optional[VPSResourceUsage]:
        ...

    @abstractmethod
    async def get_ip(self, container_name: str) -> tuple[Optional[str], Optional[str]]:
        """Returns (ipv4, ipv6)."""

    @abstractmethod
    async def reset_password(self, container_name: str, username: str, new_password: str) -> None:
        ...

    @abstractmethod
    async def host_capacity(self) -> dict:
        """Returns dict describing host-level {cpu_total, ram_total_mb, disk_total_gb,
        cpu_available, ram_available_mb, disk_available_gb} for allocation checks."""


def get_provider(provider_type: str) -> VPSProvider:
    """Factory — returns the configured provider instance."""
    provider_type = provider_type.lower()
    if provider_type == "docker":
        from providers.docker import DockerProvider
        return DockerProvider()
    if provider_type in ("lxc", "lxd"):
        from providers.lxc import LXCProvider
        return LXCProvider()
    if provider_type == "proxmox":
        from providers.proxmox import ProxmoxProvider
        return ProxmoxProvider()
    raise ProviderError(
        f"Unknown or unimplemented PROVIDER_TYPE '{provider_type}'. "
        "Implement a class satisfying providers.base.VPSProvider and register it in get_provider()."
    )
