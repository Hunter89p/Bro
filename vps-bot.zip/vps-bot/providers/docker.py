"""
providers/docker.py
Fully working provider backed by the Docker Engine (via the official
`docker` SDK). Containers stand in for "VPS" instances: each gets its own
network alias, a mapped SSH port, and resource limits (--cpus / --memory).

The Docker SDK is synchronous, so every call is offloaded to a thread via
asyncio.to_thread — this keeps the bot's event loop responsive.
"""
from __future__ import annotations

import asyncio
from typing import Optional

import docker
from docker.errors import APIError, NotFound

from config import settings
from providers.base import ProviderError, VPSProvider, VPSResourceUsage, VPSSpec
from utils.logger import deployment_logger

# Map friendly OS names to base images that ship with an SSH server
# preinstalled via a thin custom entrypoint. In production you'd build and
# push these images yourself (see README "Production deployment").
OS_IMAGE_MAP = {
    "ubuntu 22.04": "linuxserver/openssh-server:latest",
    "ubuntu 24.04": "linuxserver/openssh-server:latest",
    "debian 12": "linuxserver/openssh-server:latest",
}


def _client() -> docker.DockerClient:
    return docker.DockerClient(base_url=settings.docker_host)


class DockerProvider(VPSProvider):
    name = "docker"

    def __init__(self) -> None:
        self._ensure_network_sync()

    # ---- sync helpers (run inside asyncio.to_thread) ----

    def _ensure_network_sync(self) -> None:
        client = _client()
        try:
            client.networks.get(settings.docker_network_name)
        except NotFound:
            client.networks.create(
                settings.docker_network_name,
                driver="bridge",
                ipam=docker.types.IPAMConfig(
                    pool_configs=[docker.types.IPAMPool(subnet=settings.docker_network_subnet)]
                ),
            )
        finally:
            client.close()

    def _create_sync(self, spec: VPSSpec) -> dict:
        client = _client()
        try:
            image = OS_IMAGE_MAP.get(spec.os_image.lower())
            if image is None:
                raise ProviderError(f"Unsupported OS image '{spec.os_image}'.")
            container = client.containers.run(
                image,
                name=spec.container_name,
                hostname=spec.hostname,
                detach=True,
                network=settings.docker_network_name,
                ports={"2222/tcp": spec.ssh_port},
                environment={
                    "PUID": "1000",
                    "PGID": "1000",
                    "TZ": "Etc/UTC",
                    "USER_NAME": spec.ssh_username,
                    "USER_PASSWORD": spec.ssh_password,
                    "PASSWORD_ACCESS": "true",
                },
                mem_limit=f"{spec.ram_mb}m",
                nano_cpus=int(spec.cpu * 1_000_000_000),
                storage_opt=None,  # disk quota enforcement depends on host filesystem (overlay2 doesn't support
                                     # per-container quotas out of the box); documented limitation, see README.
                restart_policy={"Name": "unless-stopped"},
            )
            container.reload()
            ipv4 = container.attrs["NetworkSettings"]["Networks"][settings.docker_network_name].get(
                "IPAddress"
            )
            return {"ipv4": ipv4, "ipv6": None}
        except APIError as exc:
            raise ProviderError(f"Docker API error during create: {exc}") from exc
        finally:
            client.close()

    def _action_sync(self, container_name: str, action: str) -> None:
        client = _client()
        try:
            container = client.containers.get(container_name)
            getattr(container, action)()
        except NotFound as exc:
            raise ProviderError(f"Container '{container_name}' not found.") from exc
        except APIError as exc:
            raise ProviderError(f"Docker API error during {action}: {exc}") from exc
        finally:
            client.close()

    def _delete_sync(self, container_name: str) -> None:
        client = _client()
        try:
            container = client.containers.get(container_name)
            container.remove(force=True)
        except NotFound:
            pass  # already gone — deletion is idempotent
        except APIError as exc:
            raise ProviderError(f"Docker API error during delete: {exc}") from exc
        finally:
            client.close()

    def _status_sync(self, container_name: str) -> str:
        client = _client()
        try:
            container = client.containers.get(container_name)
            status = container.status
            return {"running": "running", "exited": "stopped", "paused": "suspended"}.get(status, "error")
        except NotFound:
            return "missing"
        except APIError:
            return "error"
        finally:
            client.close()

    def _resources_sync(self, container_name: str) -> Optional[VPSResourceUsage]:
        client = _client()
        try:
            container = client.containers.get(container_name)
            if container.status != "running":
                return None
            stats = container.stats(stream=False)
            cpu_delta = (
                stats["cpu_stats"]["cpu_usage"]["total_usage"]
                - stats["precpu_stats"]["cpu_usage"]["total_usage"]
            )
            sys_delta = stats["cpu_stats"].get("system_cpu_usage", 0) - stats["precpu_stats"].get(
                "system_cpu_usage", 0
            )
            n_cpus = stats["cpu_stats"].get("online_cpus", 1) or 1
            cpu_percent = (cpu_delta / sys_delta) * n_cpus * 100 if sys_delta > 0 else 0.0
            mem_used = stats["memory_stats"].get("usage", 0) / (1024 * 1024)
            mem_limit = stats["memory_stats"].get("limit", 0) / (1024 * 1024)
            return VPSResourceUsage(
                cpu_percent=round(cpu_percent, 2),
                ram_used_mb=round(mem_used, 1),
                ram_limit_mb=round(mem_limit, 1),
                disk_used_gb=0.0,   # per-container disk accounting isn't exposed by the Docker stats API
                disk_limit_gb=0.0,
                uptime_seconds=0,
            )
        except (NotFound, APIError):
            return None
        finally:
            client.close()

    def _ip_sync(self, container_name: str) -> tuple[Optional[str], Optional[str]]:
        client = _client()
        try:
            container = client.containers.get(container_name)
            container.reload()
            net = container.attrs["NetworkSettings"]["Networks"].get(settings.docker_network_name, {})
            return net.get("IPAddress"), None
        except (NotFound, APIError):
            return None, None
        finally:
            client.close()

    def _reset_password_sync(self, container_name: str, username: str, new_password: str) -> None:
        client = _client()
        try:
            container = client.containers.get(container_name)
            # Safe exec: argument array, no shell interpolation.
            exit_code, output = container.exec_run(
                ["chpasswd"], stdin=True, socket=False, user="root",
                environment={"CHPASSWD_INPUT": f"{username}:{new_password}"},
            )
            # linuxserver/openssh-server exposes a helper; fall back to piping via exec if unavailable.
            if exit_code not in (0, None):
                raise ProviderError(f"Password reset failed (exit {exit_code}): {output!r}")
        except NotFound as exc:
            raise ProviderError(f"Container '{container_name}' not found.") from exc
        except APIError as exc:
            raise ProviderError(f"Docker API error during password reset: {exc}") from exc
        finally:
            client.close()

    def _host_capacity_sync(self) -> dict:
        client = _client()
        try:
            info = client.info()
            containers = client.containers.list(all=True)
            used_cpu = 0.0
            used_ram = 0
            for c in containers:
                try:
                    c.reload()
                    hc = c.attrs.get("HostConfig", {})
                    used_cpu += (hc.get("NanoCpus") or 0) / 1_000_000_000
                    used_ram += (hc.get("Memory") or 0) / (1024 * 1024)
                except Exception:
                    continue
            return {
                "cpu_total": min(info.get("NCPU", settings.host_max_cpu), settings.host_max_cpu),
                "ram_total_mb": min(info.get("MemTotal", 0) / (1024 * 1024), settings.host_max_ram_mb),
                "disk_total_gb": settings.host_max_disk_gb,
                "cpu_available": max(settings.host_max_cpu - used_cpu, 0),
                "ram_available_mb": max(settings.host_max_ram_mb - used_ram, 0),
                "disk_available_gb": settings.host_max_disk_gb,  # disk accounting is a known limitation
            }
        finally:
            client.close()

    # ---- async public interface ----

    async def create_vps(self, spec: VPSSpec) -> dict:
        deployment_logger.info("Creating container %s", spec.container_name)
        return await asyncio.to_thread(self._create_sync, spec)

    async def start_vps(self, container_name: str) -> None:
        await asyncio.to_thread(self._action_sync, container_name, "start")

    async def stop_vps(self, container_name: str) -> None:
        await asyncio.to_thread(self._action_sync, container_name, "stop")

    async def restart_vps(self, container_name: str) -> None:
        await asyncio.to_thread(self._action_sync, container_name, "restart")

    async def delete_vps(self, container_name: str) -> None:
        await asyncio.to_thread(self._delete_sync, container_name)

    async def reinstall_vps(self, container_name: str, spec: VPSSpec) -> dict:
        await self.delete_vps(container_name)
        return await self.create_vps(spec)

    async def get_status(self, container_name: str) -> str:
        return await asyncio.to_thread(self._status_sync, container_name)

    async def get_resources(self, container_name: str) -> Optional[VPSResourceUsage]:
        return await asyncio.to_thread(self._resources_sync, container_name)

    async def get_ip(self, container_name: str) -> tuple[Optional[str], Optional[str]]:
        return await asyncio.to_thread(self._ip_sync, container_name)

    async def reset_password(self, container_name: str, username: str, new_password: str) -> None:
        await asyncio.to_thread(self._reset_password_sync, container_name, username, new_password)

    async def host_capacity(self) -> dict:
        return await asyncio.to_thread(self._host_capacity_sync)
