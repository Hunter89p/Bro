"""
providers/lxc.py
Interface stub for an LXC/LXD-backed provider.

NOT fully implemented: doing so requires a real Linux host running LXD
with its REST API exposed (LXD_HOST) and trusted client certs. The shape
below satisfies providers.base.VPSProvider so the rest of the bot can
target it once wired up — implement each method using `pylxd` or LXD's
REST API directly, following the same pattern as providers/docker.py
(offload blocking calls via asyncio.to_thread, translate backend errors
into ProviderError, never leak raw tracebacks).

Suggested implementation approach:
  pip install pylxd
  client = pylxd.Client(endpoint=settings.lxc_host, cert=(...), verify=...)
  client.containers.create(config, wait=True) / .start() / .stop() / .delete()
"""
from __future__ import annotations

from typing import Optional

from providers.base import ProviderError, VPSProvider, VPSResourceUsage, VPSSpec


class LXCProvider(VPSProvider):
    name = "lxc"

    def __init__(self) -> None:
        raise ProviderError(
            "LXCProvider is a documented interface stub, not a working implementation. "
            "Set LXC_HOST and implement the methods in providers/lxc.py using pylxd "
            "before selecting PROVIDER_TYPE=lxc."
        )

    async def create_vps(self, spec: VPSSpec) -> dict:
        raise NotImplementedError

    async def start_vps(self, container_name: str) -> None:
        raise NotImplementedError

    async def stop_vps(self, container_name: str) -> None:
        raise NotImplementedError

    async def restart_vps(self, container_name: str) -> None:
        raise NotImplementedError

    async def delete_vps(self, container_name: str) -> None:
        raise NotImplementedError

    async def reinstall_vps(self, container_name: str, spec: VPSSpec) -> dict:
        raise NotImplementedError

    async def get_status(self, container_name: str) -> str:
        raise NotImplementedError

    async def get_resources(self, container_name: str) -> Optional[VPSResourceUsage]:
        raise NotImplementedError

    async def get_ip(self, container_name: str) -> tuple[Optional[str], Optional[str]]:
        raise NotImplementedError

    async def reset_password(self, container_name: str, username: str, new_password: str) -> None:
        raise NotImplementedError

    async def host_capacity(self) -> dict:
        raise NotImplementedError
