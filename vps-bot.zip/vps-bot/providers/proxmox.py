"""
providers/proxmox.py
Interface stub for a Proxmox VE-backed provider.

NOT fully implemented: requires a real Proxmox server (PROXMOX_HOST) and
an API token (PROXMOX_TOKEN) with permission to manage VMs/containers.
Implement using `proxmoxer`, mirroring providers/docker.py's pattern:

  pip install proxmoxer requests
  proxmox = ProxmoxAPI(host, token_name=..., token_value=..., verify_ssl=True)
  proxmox.nodes(node).lxc.create(vmid=..., ostemplate=..., cores=..., memory=..., ...)
  proxmox.nodes(node).lxc(vmid).status.start.post()

Clone a template per plan/OS combination for fast provisioning, or use
`pct create` semantics via the API for from-scratch installs.
"""
from __future__ import annotations

from typing import Optional

from providers.base import ProviderError, VPSProvider, VPSResourceUsage, VPSSpec


class ProxmoxProvider(VPSProvider):
    name = "proxmox"

    def __init__(self) -> None:
        raise ProviderError(
            "ProxmoxProvider is a documented interface stub, not a working implementation. "
            "Set PROXMOX_HOST and PROXMOX_TOKEN and implement the methods in "
            "providers/proxmox.py using proxmoxer before selecting PROVIDER_TYPE=proxmox."
        )

    async def create_vps(self, spec: VPSSpec) -> dict:
        raise NotImplementedError

    async def start_vps(self, container_name: str) -> None:
        raise NotImplementedError

    async def stop_vps(self, container_name: str) -> None:
        raise NotImplementedError

    async def restart_vps(self, container_name: str) -> None:
        raise NotImplementedError

    async def delete_vps(self, container_name: str) -> None:
        raise NotImplementedError

    async def reinstall_vps(self, container_name: str, spec: VPSSpec) -> dict:
        raise NotImplementedError

    async def get_status(self, container_name: str) -> str:
        raise NotImplementedError

    async def get_resources(self, container_name: str) -> Optional[VPSResourceUsage]:
        raise NotImplementedError

    async def get_ip(self, container_name: str) -> tuple[Optional[str], Optional[str]]:
        raise NotImplementedError

    async def reset_password(self, container_name: str, username: str, new_password: str) -> None:
        raise NotImplementedError

    async def host_capacity(self) -> dict:
        raise NotImplementedError
